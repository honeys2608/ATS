from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from app.db import get_db
from app import models, schemas
from app.schemas import CandidateMatchRequest      # important
from app.ai_core import generate_fit_explanation

router = APIRouter(prefix="/v1/candidates", tags=["Candidate Matching"])


@router.post("/match")
def match_candidates(payload: CandidateMatchRequest, db: Session = Depends(get_db)):

    job_id = payload.job_id
    limit = payload.limit or 10

    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        raise HTTPException(404, "Job not found")

    candidates = db.query(models.Candidate).all()
    results = []

    for c in candidates:

        # Convert experience safely
        try:
            exp = float(c.experience_years or 0)
        except:
            exp = 0

        job_exp = float(job.min_experience or 0)

        # ----------- SKILL MATCHING (50%) ----------
        job_skills = set(job.skills or [])
        cand_skills = set(c.skills or [])

        if job_skills:
            skill_match = len(job_skills.intersection(cand_skills))
            skill_score = (skill_match / len(job_skills)) * 50
        else:
            skill_score = 0

        # ----------- EXPERIENCE MATCH (30%) ----------
        if exp >= job_exp:
            exp_score = 30
        else:
            exp_score = (exp / job_exp) * 30 if job_exp > 0 else 10

        # ----------- LOCATION SCORE (20%) ----------
        loc_score = 20 if c.current_location == job.location else 10

        # Final score
        fit_score = round(skill_score + exp_score + loc_score, 2)

        # Explanation from AI text generator
        explanation = generate_fit_explanation(
            candidate_data={"parsed_resume": {"skills": list(cand_skills)}},
            job_data={"skills": list(job_skills)},
            fit_score=fit_score
        )

        results.append({
            "candidate_id": c.id,
            "name": c.full_name,
            "email": c.email,
            "phone": c.phone,
            "experience": exp,
            "location": c.current_location,
            "fit_score": fit_score,
            "top_factors": explanation.get("top_factors", [])
        })

    return {
        "job_id": job.id,
        "job_title": job.title,
        "total_candidates_checked": len(results),
        "matches": sorted(results, key=lambda x: x["fit_score"], reverse=True)[:limit]
    }
