from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, List, Any

from app.db import get_db
from app import models, schemas
from app.auth import get_current_user
from app.permissions import require_permission, ROLE_PERMISSIONS

router = APIRouter(prefix="/v1/permissions-matrix", tags=["Permissions Matrix"])


# -----------------------------------------------------------
# GET PERMISSIONS MATRIX  (Frontend: Table View)
# -----------------------------------------------------------
@router.get("", response_model=Dict[str, Any])
@require_permission("settings", "view")
def get_permissions_matrix(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    # Load all roles from DB (sorted)
    roles = db.query(models.Role).order_by(models.Role.id).all()
    roles_list = [{"id": r.id, "name": r.name} for r in roles]

    # Load permissions table
    perms = db.query(models.Permission).all()

    # Build matrix: module → action → [roles]
    matrix: Dict[str, Dict[str, List[str]]] = {}

    for p in perms:
        module = p.module_name
        action = p.action_name
        role = p.role_name

        if module not in matrix:
            matrix[module] = {}

        if action not in matrix[module]:
            matrix[module][action] = []

        if role not in matrix[module][action]:
            matrix[module][action].append(role)

    return {
        "roles": roles_list,
        "matrix": matrix,
        "permissions_total": len(perms)
    }


# -----------------------------------------------------------
# LIST ALL PERMISSIONS (admin table)
# -----------------------------------------------------------
@router.get("/list", response_model=List[schemas.PermissionResponse])
@require_permission("settings", "view")
def list_permissions(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    return (
        db.query(models.Permission)
        .order_by(models.Permission.created_at.desc())
        .all()
    )


# -----------------------------------------------------------
# CREATE PERMISSION (with validation)
# -----------------------------------------------------------
@router.post("", response_model=schemas.PermissionResponse, status_code=201)
@require_permission("settings", "update")
def create_permission(
    data: schemas.PermissionCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    # Validate role exists
    if data.role_name not in ROLE_PERMISSIONS:
        raise HTTPException(400, detail="Invalid role")

    # Validate module exists for this role
    if data.module_name not in ROLE_PERMISSIONS[data.role_name]:
        raise HTTPException(400, detail="Invalid module for this role")

    # Validate action exists
    valid_actions = ROLE_PERMISSIONS[data.role_name][data.module_name]
    if data.action_name not in valid_actions:
        raise HTTPException(
            400,
            detail=f"Invalid action. Allowed actions: {valid_actions}"
        )

    # Prevent duplicate
    existing = db.query(models.Permission).filter(
        models.Permission.role_name == data.role_name,
        models.Permission.module_name == data.module_name,
        models.Permission.action_name == data.action_name
    ).first()

    if existing:
        raise HTTPException(400, detail="Permission already exists")

    # Create
    perm = models.Permission(
        role_name=data.role_name,
        module_name=data.module_name,
        action_name=data.action_name
    )

    db.add(perm)
    db.commit()
    db.refresh(perm)

    return perm


# -----------------------------------------------------------
# DELETE PERMISSION
# -----------------------------------------------------------
@router.delete("/{permission_id}", status_code=204)
@require_permission("settings", "update")
def delete_permission(
    permission_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    perm = db.query(models.Permission).filter(models.Permission.id == permission_id).first()

    if not perm:
        raise HTTPException(404, detail="Permission not found")

    db.delete(perm)
    db.commit()

    return


# -----------------------------------------------------------
# RESET MATRIX (Danger – Admin Only)
# -----------------------------------------------------------
@router.post("/reset", status_code=200)
@require_permission("settings", "update")
def reset_permission_matrix(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    db.query(models.Permission).delete()
    db.commit()

    return {"message": "All permissions cleared. Re-seed required."}