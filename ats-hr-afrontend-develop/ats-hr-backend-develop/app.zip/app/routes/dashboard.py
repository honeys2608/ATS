from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import Job, Candidate, JobApplication
from app.permissions import require_permission
from app.auth import get_current_user

router = APIRouter(prefix="/v1/dashboard", tags=["Dashboard Metrics"])


@router.get("/metrics")
@require_permission("dashboard", "view")
def get_dashboard_metrics(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    user_role = current_user.get("role")
    user_id = current_user.get("id")

    # ================================
    # ⭐ ADMIN → SEE ALL DATA
    # ================================
    if user_role == "admin":
        total_jobs_open = db.query(Job).filter(
            Job.status.in_(["open", "active", "OPEN", "Active"])
        ).count()

        total_candidates = db.query(Candidate).count()

        interviews_scheduled = db.query(JobApplication).filter(
            JobApplication.status == "interview_scheduled"
        ).count()

        offers_pending = db.query(JobApplication).filter(
            JobApplication.status == "offer_made"
        ).count()

        employees_onboarding = db.query(JobApplication).filter(
            JobApplication.status == "hired"
        ).count()

    # ================================
    # ⭐ RECRUITER → ONLY HIS DATA
    # ================================
    else:
       jobs = db.query(Job).join(Job.recruiters).filter(
        Job.recruiters.any(id=user_id)
       ).all()

       job_ids = [j.id for j in jobs]

       total_jobs_open = len(jobs)

    # 🔥 GLOBAL CANDIDATE COUNT
       total_candidates = db.query(Candidate).count()

       interviews_scheduled = db.query(JobApplication).filter(
        JobApplication.job_id.in_(job_ids),
        JobApplication.status == "interview_scheduled"
       ).count()

       offers_pending = db.query(JobApplication).filter(
        JobApplication.job_id.in_(job_ids),
        JobApplication.status == "offer_made"
       ).count()

       employees_onboarding = db.query(JobApplication).filter(
        JobApplication.job_id.in_(job_ids),
        JobApplication.status == "hired"
      ).count()

    # ================================
    # FINAL RESPONSE
    # ================================
    revenue_projected = total_jobs_open * 50000
    revenue_realized = employees_onboarding * 60000

    return {
        "total_jobs_open": total_jobs_open,
        "total_candidates": total_candidates,
        "interviews_scheduled": interviews_scheduled,
        "offers_pending": offers_pending,
        "employees_onboarding": employees_onboarding,
        "revenue_projected": revenue_projected,
        "revenue_realized": revenue_realized,
        "time_to_hire_avg": 12,
    }
