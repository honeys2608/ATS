# app/routes/live_interviews.py

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from datetime import datetime
import uuid

from app.db import get_db
from app.auth import get_current_user
from app import models, schemas


router = APIRouter(
    prefix="/v1/live-interviews",
    tags=["Live Interviews"]
)

# ============================================================
# 1️⃣ CREATE LIVE INTERVIEW (FIXED)
@router.post("", response_model=schemas.LiveInterviewJoinResponse, dependencies=[Depends(get_current_user)])
def create_live_interview(
    data: schemas.LiveInterviewCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    candidate = db.query(models.Candidate).filter(models.Candidate.id == data.candidate_id).first()
    job = db.query(models.Job).filter(models.Job.id == data.job_id).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")
    if not job:
        raise HTTPException(404, "Job not found")

    # ✅ Meeting URL logic
    meeting_url = None
    if data.type == "video":
        meeting_url = (
            data.meeting_link
            if data.meeting_link
            else f"https://meet.yourapp.com/{uuid.uuid4().hex[:8]}"
        )

    interview = models.LiveInterview(
        candidate_id=data.candidate_id,
        job_id=data.job_id,
        interviewer_id=current_user.get("id"),
        scheduled_at=data.scheduled_at,      # ✅ FIXED
        meeting_url=meeting_url,              # ✅ FIXED
        recording_enabled=data.recording_enabled,
        status="scheduled"
    )

    db.add(interview)
    db.commit()
    db.refresh(interview)

    return {
        "interview_id": interview.id,
        "meeting_url": interview.meeting_url,
        "recording_enabled": interview.recording_enabled
    }


# ============================================================
# 2️⃣ LIST LIVE INTERVIEWS
# ============================================================
@router.get(
    "",
    response_model=list[schemas.LiveInterviewBase],
    dependencies=[Depends(get_current_user)]
)
def list_live_interviews(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    query = (
        db.query(models.LiveInterview)
        .options(
            joinedload(models.LiveInterview.candidate),
            joinedload(models.LiveInterview.job),
        )
        .order_by(models.LiveInterview.created_at.desc())
    )

    if current_user.get("role") == "candidate" and current_user.get("candidate"):
        query = query.filter(
            models.LiveInterview.candidate_id
            == current_user["candidate"]["id"]
        )

    return query.all()


# ============================================================
# 3️⃣ LIVE INTERVIEW DETAIL
# ============================================================
@router.get(
    "/{interview_id}",
    response_model=schemas.LiveInterviewBase,
    dependencies=[Depends(get_current_user)]
)
def get_live_interview_detail(
    interview_id: str,
    db: Session = Depends(get_db),
):
    interview = (
        db.query(models.LiveInterview)
        .options(
            joinedload(models.LiveInterview.candidate),
            joinedload(models.LiveInterview.job),
        )
        .filter(models.LiveInterview.id == interview_id)
        .first()
    )

    if not interview:
        raise HTTPException(status_code=404, detail="Live interview not found")

    return interview


# ============================================================
# 🔁 BACKWARD COMPATIBILITY
# ============================================================
alias_router = APIRouter(prefix="/v1/interviews", tags=["Interviews Alias"])

@alias_router.get("/{interview_id}")
def get_any_interview(
    interview_id: str,
    db: Session = Depends(get_db),
):
    interview = (
        db.query(models.LiveInterview)
        .options(
            joinedload(models.LiveInterview.candidate),
            joinedload(models.LiveInterview.job),
        )
        .filter(models.LiveInterview.id == interview_id)
        .first()
    )

    if not interview:
        raise HTTPException(status_code=404, detail="Interview not found")

    return interview
