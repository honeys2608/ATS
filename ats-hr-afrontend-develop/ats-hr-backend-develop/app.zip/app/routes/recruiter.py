from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime

from app.db import get_db
from app import models
from app.auth import get_current_user
from sqlalchemy.orm import joinedload
from pydantic import BaseModel, EmailStr, validator

from app.schemas import JobSubmissionCreate

from fastapi import UploadFile, File, Form
import secrets
import shutil
import os
from app.models import UserPreferences, PasswordResetLog, AccountActivityLog
from app.auth import verify_password, get_password_hash, create_access_token
from datetime import timedelta
import app.utils as app_utils_utils

# ============================================================
# SCHEMA FOR VALIDATION
# ============================================================
class RecruiterProfileUpdate(BaseModel):
    full_name: str = None
    phone: str = None
    
    @validator('full_name')
    def validate_full_name(cls, v):
        if v and len(v) < 2:
            raise ValueError('Full name must be at least 2 characters')
        if v and len(v) > 100:
            raise ValueError('Full name cannot exceed 100 characters')
        if v and not v[0].isupper():
            raise ValueError('Full name must start with capital letter')
        return v
    
    @validator('phone')
    def validate_phone(cls, v):
        if not v:
            return v
        # 10 digits format
        phone_digits = ''.join(filter(str.isdigit, v))
        if len(phone_digits) != 10:
            raise ValueError('Phone must be exactly 10 digits')
        return v


# ============================================================
# CALL FEEDBACK SCHEMAS
# ============================================================
class CallFeedbackCreate(BaseModel):
    candidate_id: str
    call_type: str  # Initial Screening, HR Round, Technical Discussion, Follow-up
    call_date: datetime
    call_duration: int = None  # minutes
    call_mode: str  # Phone, Google Meet, Zoom, WhatsApp
    ratings: dict  # { "communication": 4, "technical_fit": 3, ... }
    salary_alignment: str  # Yes, No, Negotiable
    strengths: str = None
    concerns: str = None
    additional_notes: str = None
    candidate_intent: str = None  # Actively looking, Passive, Offer in hand, Just exploring
    decision: str  # Proceed to Next Round, Hold / Revisit Later, Reject, Needs Another Call
    rejection_reason: str = None  # Skill mismatch, Salary mismatch, Experience mismatch, Not interested, No show
    next_actions: list = None  # ["Schedule technical interview", ...]
    is_draft: bool = True


class CallFeedbackUpdate(BaseModel):
    call_type: str = None
    call_date: datetime = None
    call_duration: int = None
    call_mode: str = None
    ratings: dict = None
    salary_alignment: str = None
    strengths: str = None
    concerns: str = None
    additional_notes: str = None
    candidate_intent: str = None
    decision: str = None
    rejection_reason: str = None
    next_actions: list = None
    is_draft: bool = None


class CallFeedbackResponse(BaseModel):
    id: str
    candidate_id: str
    recruiter_id: str
    call_type: str
    call_date: datetime
    call_duration: int
    call_mode: str
    ratings: dict
    salary_alignment: str
    strengths: str
    concerns: str
    additional_notes: str
    candidate_intent: str
    decision: str
    rejection_reason: str
    next_actions: list
    is_draft: bool
    created_at: datetime
    updated_at: datetime


router = APIRouter(
    prefix="/v1/recruiter",
    tags=["Recruiter"]
)


# ------------------------------------------------------------------
# 0️⃣ GET RECRUITER PROFILE
# ------------------------------------------------------------------
@router.get("/profile")
def get_recruiter_profile(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Get recruiter's own profile information"""
    recruiter_id = current_user["id"]
    
    user = db.query(models.User).filter(
        models.User.id == recruiter_id
    ).first()
    
    if not user:
        raise HTTPException(404, "Recruiter not found")
    
    # Get count of assigned jobs
    assigned_jobs_count = db.query(models.job_recruiters).filter(
        models.job_recruiters.c.recruiter_id == recruiter_id
    ).count()
    
    # Get count of active applications
    active_apps_count = db.query(models.JobApplication).join(
        models.Job
    ).filter(
        models.job_recruiters.c.recruiter_id == recruiter_id,
        models.JobApplication.status.in_(['new', 'reviewed'])
    ).count()
    
    return {
        "id": user.id,
        "username": user.username,
        "full_name": user.full_name or "",
        "email": user.email,
        "phone": user.phone if hasattr(user, 'phone') else None,
        "role": user.role,
        "company_name": user.company_name,
        "is_active": user.is_active,
        "created_at": user.created_at.isoformat() if user.created_at else None,
        "assigned_jobs_count": assigned_jobs_count,
        "active_applications_count": active_apps_count
    }


# ------------------------------------------------------------------
# 1️⃣ UPDATE RECRUITER PROFILE
# ------------------------------------------------------------------
@router.put("/profile")
def update_recruiter_profile(
    profile_data: RecruiterProfileUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Update recruiter's profile information"""
    recruiter_id = current_user["id"]
    
    user = db.query(models.User).filter(
        models.User.id == recruiter_id
    ).first()
    
    if not user:
        raise HTTPException(404, "Recruiter not found")
    
    # Update only provided fields
    if profile_data.full_name is not None:
        user.full_name = profile_data.full_name
    
    if profile_data.phone is not None:
        if hasattr(user, 'phone'):
            user.phone = profile_data.phone
        else:
            raise HTTPException(400, "Phone field not supported for this user")

    # Profile photo upload handled separately
    
    try:
        db.commit()
        db.refresh(user)
        return {
            "message": "Profile updated successfully",
            "id": user.id,
            "username": user.username,
            "full_name": user.full_name,
            "email": user.email,
            "phone": user.phone if hasattr(user, 'phone') else None,
            "updated_at": datetime.utcnow().isoformat()
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(400, f"Update failed: {str(e)}")


# ---------------- PROFILE PHOTO UPLOAD ----------------
@router.post("/profile/photo")
def upload_profile_photo(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    user = db.query(models.User).filter(models.User.id == current_user["id"]).first()
    if not user:
        raise HTTPException(404, "User not found")
    ext = os.path.splitext(file.filename)[-1]
    filename = f"profile_{user.id}{ext}"
    upload_dir = "uploads/profile_photos"
    os.makedirs(upload_dir, exist_ok=True)
    file_path = os.path.join(upload_dir, filename)
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    user.photo_url = f"/uploads/profile_photos/{filename}"
    db.commit()
    db.refresh(user)
    return {"message": "Profile photo updated", "photo_url": user.photo_url}


# ---------------- EMAIL CHANGE WITH OTP ----------------
@router.post("/profile/email-change-request")
def request_email_change(
    new_email: str = Form(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    user = db.query(models.User).filter(models.User.id == current_user["id"]).first()
    if not user:
        raise HTTPException(404, "User not found")
    if db.query(models.User).filter(models.User.email == new_email).first():
        raise HTTPException(400, "Email already in use")
    otp = secrets.randbelow(1000000)
    otp = f"{otp:06d}"
    user.otp_code = otp
    user.otp_expiry = datetime.utcnow() + timedelta(minutes=5)
    db.commit()
    # Send OTP to both old and new email
    app_utils_utils.send_otp_email(user.email, otp, "Email Change Verification")
    app_utils_utils.send_otp_email(new_email, otp, "Email Change Verification")
    return {"message": "OTP sent to both emails"}

@router.post("/profile/email-change-verify")
def verify_email_change(
    new_email: str = Form(...),
    otp: str = Form(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    user = db.query(models.User).filter(models.User.id == current_user["id"]).first()
    if not user:
        raise HTTPException(404, "User not found")
    if user.otp_code != otp or not user.otp_expiry or user.otp_expiry < datetime.utcnow():
        raise HTTPException(400, "Invalid or expired OTP")
    user.email = new_email
    user.otp_code = None
    user.otp_expiry = None
    db.commit()
    db.refresh(user)
    return {"message": "Email updated successfully", "email": user.email}


# ---------------- CHANGE PASSWORD ----------------
@router.post("/change-password")
def change_password(
    current_password: str = Form(...),
    new_password: str = Form(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    user = db.query(models.User).filter(models.User.id == current_user["id"]).first()
    if not user:
        raise HTTPException(404, "User not found")
    if not verify_password(current_password, user.password):
        raise HTTPException(400, "Current password incorrect")
    # Password validation
    if len(new_password) < 8 or not any(c.isupper() for c in new_password) or not any(c.isdigit() for c in new_password) or not any(c in '!@#$%^&*()_+-=' for c in new_password):
        raise HTTPException(400, "Password must be 8+ chars, 1 uppercase, 1 number, 1 special char")
    user.password = get_password_hash(new_password)
    db.commit()
    # Log activity
    db.add(AccountActivityLog(user_id=user.id, action_type="password_change", ip_address=app_utils_utils.get_client_ip(), device_info=app_utils_utils.get_device_info()))
    db.commit()
    return {"message": "Password changed successfully"}


# ---------------- RESET PASSWORD (FORGOT FLOW) ----------------
@router.post("/reset-password-request")
def reset_password_request(
    email: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        raise HTTPException(404, "User not found")
    log = db.query(PasswordResetLog).filter(PasswordResetLog.user_id == user.id).first()
    now = datetime.utcnow()
    if log and log.last_reset_date and (now - log.last_reset_date).days < 30 and log.reset_count >= 2:
        log.is_locked = True
        db.commit()
        return {"status": "blocked", "message": "Account Manager approval required"}
    otp = secrets.randbelow(1000000)
    otp = f"{otp:06d}"
    user.otp_code = otp
    user.otp_expiry = now + timedelta(minutes=5)
    db.commit()
    app_utils_utils.send_otp_email(user.email, otp, "Password Reset OTP")
    return {"message": "OTP sent to email"}

@router.post("/reset-password-verify")
def reset_password_verify(
    email: str = Form(...),
    otp: str = Form(...),
    new_password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(models.User).filter(models.User.email == email).first()
    if not user:
        raise HTTPException(404, "User not found")
    if user.otp_code != otp or not user.otp_expiry or user.otp_expiry < datetime.utcnow():
        raise HTTPException(400, "Invalid or expired OTP")
    # Check reset log
    log = db.query(PasswordResetLog).filter(PasswordResetLog.user_id == user.id).first()
    now = datetime.utcnow()
    if log and log.last_reset_date and (now - log.last_reset_date).days < 30 and log.reset_count >= 2:
        log.is_locked = True
        db.commit()
        return {"status": "blocked", "message": "Account Manager approval required"}
    # Password validation
    if len(new_password) < 8 or not any(c.isupper() for c in new_password) or not any(c.isdigit() for c in new_password) or not any(c in '!@#$%^&*()_+-=' for c in new_password):
        raise HTTPException(400, "Password must be 8+ chars, 1 uppercase, 1 number, 1 special char")
    user.password = get_password_hash(new_password)
    user.otp_code = None
    user.otp_expiry = None
    # Update/reset log
    if not log:
        log = PasswordResetLog(user_id=user.id, reset_count=1, last_reset_date=now, is_locked=False)
        db.add(log)
    else:
        if log.last_reset_date and (now - log.last_reset_date).days < 30:
            log.reset_count += 1
        else:
            log.reset_count = 1
        log.last_reset_date = now
        log.is_locked = False
    db.commit()
    # Log activity
    db.add(AccountActivityLog(user_id=user.id, action_type="password_reset", ip_address=app_utils_utils.get_client_ip(), device_info=app_utils_utils.get_device_info()))
    db.commit()
    return {"message": "Password reset successfully"}


# ---------------- PRODUCT SETTINGS (USER PREFERENCES) ----------------
@router.get("/preferences")
def get_user_preferences(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    prefs = db.query(UserPreferences).filter(UserPreferences.user_id == current_user["id"]).first()
    if not prefs:
        prefs = UserPreferences(user_id=current_user["id"])
        db.add(prefs)
        db.commit()
        db.refresh(prefs)
    return {
        "email_notifications": prefs.email_notifications,
        "sms_alerts": prefs.sms_alerts,
        "report_emails": prefs.report_emails,
        "interview_reminders": prefs.interview_reminders,
        "two_factor_enabled": prefs.two_factor_enabled
    }

@router.put("/preferences")
def update_user_preferences(
    email_notifications: bool = Form(...),
    sms_alerts: bool = Form(...),
    report_emails: bool = Form(...),
    interview_reminders: bool = Form(...),
    two_factor_enabled: bool = Form(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    prefs = db.query(UserPreferences).filter(UserPreferences.user_id == current_user["id"]).first()
    if not prefs:
        prefs = UserPreferences(user_id=current_user["id"])
        db.add(prefs)
    prefs.email_notifications = email_notifications
    prefs.sms_alerts = sms_alerts
    prefs.report_emails = report_emails
    prefs.interview_reminders = interview_reminders
    prefs.two_factor_enabled = two_factor_enabled
    db.commit()
    db.refresh(prefs)
    return {"message": "Preferences updated"}


# ---------------- ACCOUNT ACTIVITY LOGS ----------------
@router.get("/activity-logs")
def get_account_activity_logs(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    logs = db.query(AccountActivityLog).filter(AccountActivityLog.user_id == current_user["id"]).order_by(AccountActivityLog.timestamp.desc()).limit(100).all()
    return [
        {
            "action_type": log.action_type,
            "ip_address": log.ip_address,
            "device_info": log.device_info,
            "timestamp": log.timestamp.isoformat() if log.timestamp else None
        }
        for log in logs
    ]



@router.get("/assigned-jobs")
def get_assigned_jobs(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    recruiter_id = current_user["id"]

    jobs = (
        db.query(models.Job)
        .options(joinedload(models.Job.account_manager))  # ✅ IMPORTANT
        .join(models.job_recruiters)
        .filter(models.job_recruiters.c.recruiter_id == recruiter_id)
        .order_by(models.Job.created_at.desc())
        .all()
    )

    result = []

    for j in jobs:
        result.append({
            "id": j.id,                     # internal UUID
            "job_id": j.job_id,             # public job code
            "title": j.title,
            "location": j.location,
            "department": j.department,
            "status": j.status,
            "min_experience": j.min_experience,
            "max_experience": j.max_experience,
            "skills": j.skills if isinstance(j.skills, list) else [],
            "created_at": j.created_at,

            # ✅ ACCOUNT MANAGER (THIS WAS MISSING)
            "account_manager": {
                "id": j.account_manager.id if j.account_manager else None,
                "name": j.account_manager.full_name if j.account_manager else "—",
                "email": j.account_manager.email if j.account_manager else None,
            }
        })

    return {
        "total": len(result),
        "jobs": result
    }

# ------------------------------------------------------------------
# 2️⃣ GET SUBMISSIONS FOR A JOB (Recruiter View)
# ------------------------------------------------------------------
@router.get("/jobs/{job_id}/submissions")
def get_job_submissions(
    job_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    job = db.query(models.Job).filter(
        (models.Job.id == job_id) |
        (models.Job.job_id == job_id)
    ).first()

    if not job:
        return {"candidates": []}

    applications = (
        db.query(models.JobApplication)
        .filter(models.JobApplication.job_id == job.id)
        .all()
    )

    result = []

    # ✅ THIS LOOP MUST BE INSIDE THE FUNCTION
    for app in applications:
        result.append({
            "application_id": app.id,

            "full_name": app.full_name,
            "public_id": app.candidate.public_id if app.candidate else None,
            "candidate_id": app.candidate_id,

            "email": app.email,
            "phone": app.phone,

            "status": app.status,

            # ⭐⭐ THIS IS WHAT UI NEEDS
            "sent_to_client_at": app.sent_to_client_at,

        })

    return {
        "candidates": result
    }



# ------------------------------------------------------------------
# 3️⃣ SUBMIT CANDIDATE TO JOB
# ------------------------------------------------------------------
@router.post("/jobs/{job_id}/submit")
def submit_candidate(
    job_id: str,
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    job = db.query(models.Job).filter(
    (models.Job.id == job_id) |
    (models.Job.job_id == job_id)
).first()

    if not job:
        raise HTTPException(404, "Job not found")

    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == candidate_id
    ).first()
    if not candidate:
        raise HTTPException(404, "Candidate not found")

    # Prevent duplicate submission
    existing = db.query(models.JobApplication).filter(
        models.JobApplication.job_id == job.id,   # ✅ correct
        models.JobApplication.candidate_id == candidate_id
    ).first()

    if existing:
        raise HTTPException(400, "Candidate already submitted for this job")

    app = models.JobApplication(
        job_id=job.id,
        candidate_id=candidate_id,
        full_name=candidate.full_name,
        email=candidate.email,
        status="submitted",
        applied_at=datetime.utcnow(),
        recruiter_id=current_user["id"],   # ⭐⭐ ADD THIS (MOST IMPORTANT)
    )

    db.add(app)
    db.commit()
    db.refresh(app)

    return {
        "message": "Candidate submitted successfully",
        "application_id": app.id
    }


# ------------------------------------------------------------------
# 4️⃣ SHORTLIST CANDIDATE FOR ACCOUNT MANAGER REVIEW
# ------------------------------------------------------------------
@router.post("/applications/{application_id}/shortlist")
def shortlist_candidate_for_am(
    application_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    app = db.query(models.JobApplication).filter(
        models.JobApplication.id == application_id
    ).first()

    if not app:
        raise HTTPException(404, "Application not found")

    app.status = "interview"

    app.shortlisted_at = datetime.utcnow()

    db.commit()
    db.refresh(app)

    return {
        "message": "Candidate shortlisted for Account Manager review",
        "application_id": app.id,
        "status": app.status
    }


# ------------------------------------------------------------------
# 1.5️⃣  GET SINGLE JOB DETAILS (Recruiter View)
# ------------------------------------------------------------------
@router.get("/jobs/{job_id}")
def get_job_detail(
    job_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    job = (
    db.query(models.Job)
    .options(joinedload(models.Job.account_manager))
    .filter(models.Job.id == job_id)
    .first()
)


    if not job:
        raise HTTPException(404, "Job not found")

    return {
        "id": job.id,
        "job_id": job.job_id,
        "title": job.title,
        "location": job.location,
        "department": job.department,
        "status": job.status,
        "experience": f"{job.min_experience} - {job.max_experience} yrs" if job.min_experience else None,
        "skills": job.skills if isinstance(job.skills, list) else [job.skills] if job.skills else [],
        "created_at": job.created_at,
        # ⭐⭐ ADD THIS
        "account_manager": {
        "id": job.account_manager.id if job.account_manager else None,
        "name": job.account_manager.full_name if job.account_manager else "—",
        "email": job.account_manager.email if job.account_manager else None,
        }
    }


@router.get("/dashboard")
def recruiter_dashboard(
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    recruiter_id = current_user["id"]

    # Assigned Jobs
    assigned_jobs = (
        db.query(models.Job)
        .join(models.job_recruiters)
        .filter(models.job_recruiters.c.recruiter_id == recruiter_id)
        .count()
    )

    # Total Candidates recruiter ne submit kiye
    total_candidates = (
    db.query(models.JobApplication)
    .filter(models.JobApplication.created_by == recruiter_id)
    .count()
)



    # 👇 Yahi change hai — shortlisted nahi, interview count
    interviews = (
        db.query(models.JobApplication)
        .filter(
            models.JobApplication.created_by == recruiter_id,
            models.JobApplication.status == "interview"
        )
        .count()
    )

    # Active Pipelines (jobs jisme candidates hain)
    active_pipelines = (
        db.query(models.JobApplication.job_id)
        .filter(models.JobApplication.created_by == recruiter_id)
        .distinct()
        .count()
    )

    return {
        "assigned_jobs": assigned_jobs,
        "total_candidates": total_candidates,
        "interviews": interviews,
        "active_pipelines": active_pipelines
    }


# ------------------------------------------------------------------
# 5️⃣ SEND CANDIDATE TO ACCOUNT MANAGER
# ------------------------------------------------------------------
@router.post("/applications/{application_id}/send-to-am")
def send_candidate_to_am(
    application_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    app = db.query(models.JobApplication).filter(
        models.JobApplication.id == application_id
    ).first()

    if not app:
        raise HTTPException(404, "Application not found")

    app.status = "sent_to_am"

    if not app.sent_to_client_at:
        app.sent_to_client_at = datetime.utcnow()



    db.commit()
    db.refresh(app)

    return {
        "message": "Candidate sent to AM",
        "status": app.status
    }

@router.post("/jobs/{job_id}/submissions")
def submit_candidate_directly_to_am(
    job_id: str,
    payload: JobSubmissionCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    # 1. Resolve job (UUID or public job_id)
    job = db.query(models.Job).filter(
        (models.Job.id == job_id) |
        (models.Job.job_id == job_id)
    ).first()

    if not job:
        raise HTTPException(404, "Job not found")

    # 2. Candidate
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == payload.candidate_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")

    # 3. Prevent duplicate
    existing = db.query(models.JobApplication).filter(
        models.JobApplication.job_id == job.id,
        models.JobApplication.candidate_id == candidate.id
    ).first()

    if existing:
        raise HTTPException(400, "Candidate already submitted")

    # 4. Create JobApplication → DIRECTLY sent to AM
    app = models.JobApplication(
        job_id=job.id,
        candidate_id=candidate.id,
        full_name=candidate.full_name,
        email=candidate.email,
        phone=candidate.phone,
        status="sent_to_am",
        sent_to_client_at=datetime.utcnow(),
        recruiter_id=current_user["id"],
        applied_at=datetime.utcnow()
    )

    db.add(app)
    db.commit()
    db.refresh(app)

    return {
        "message": "Candidate sent to Account Manager",
        "application_id": app.id,
        "status": app.status
    }


# ============================================================
# CALL FEEDBACK ENDPOINTS
# ============================================================

# ------------------------------------------------------------------
# ✏️ CREATE CALL FEEDBACK
# ------------------------------------------------------------------
@router.post("/call-feedback")
def create_call_feedback(
    payload: CallFeedbackCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Create a new call feedback entry for a candidate"""
    
    # Validate candidate exists
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == payload.candidate_id
    ).first()
    
    if not candidate:
        raise HTTPException(404, "Candidate not found")
    
    # Validate decision
    valid_decisions = ["Proceed to Next Round", "Hold / Revisit Later", "Reject", "Needs Another Call"]
    if payload.decision not in valid_decisions:
        raise HTTPException(400, f"Invalid decision. Must be one of: {valid_decisions}")
    
    # If decision is Reject, rejection_reason is required
    if payload.decision == "Reject" and not payload.rejection_reason:
        raise HTTPException(400, "Rejection reason is required when decision is 'Reject'")
    
    # Validate ratings
    required_ratings = ["communication", "technical_fit", "experience_relevance", "culture_fit"]
    if not all(rating in payload.ratings for rating in required_ratings):
        raise HTTPException(400, f"All ratings required: {required_ratings}")
    
    # Create feedback entry
    feedback = models.CallFeedback(
        candidate_id=payload.candidate_id,
        recruiter_id=current_user["id"],
        call_type=payload.call_type,
        call_date=payload.call_date,
        call_duration=payload.call_duration,
        call_mode=payload.call_mode,
        ratings=payload.ratings,
        salary_alignment=payload.salary_alignment,
        strengths=payload.strengths,
        concerns=payload.concerns,
        additional_notes=payload.additional_notes,
        candidate_intent=payload.candidate_intent,
        decision=payload.decision,
        rejection_reason=payload.rejection_reason,
        next_actions=payload.next_actions,
        is_draft=payload.is_draft
    )
    
    db.add(feedback)
    db.commit()
    db.refresh(feedback)
    
    return {
        "id": feedback.id,
        "candidate_id": feedback.candidate_id,
        "recruiter_id": feedback.recruiter_id,
        "call_type": feedback.call_type,
        "call_date": feedback.call_date,
        "call_duration": feedback.call_duration,
        "call_mode": feedback.call_mode,
        "ratings": feedback.ratings,
        "salary_alignment": feedback.salary_alignment,
        "strengths": feedback.strengths,
        "concerns": feedback.concerns,
        "additional_notes": feedback.additional_notes,
        "candidate_intent": feedback.candidate_intent,
        "decision": feedback.decision,
        "rejection_reason": feedback.rejection_reason,
        "next_actions": feedback.next_actions,
        "is_draft": feedback.is_draft,
        "created_at": feedback.created_at,
        "updated_at": feedback.updated_at,
        "message": "Call feedback created successfully"
    }


# ------------------------------------------------------------------
# 📋 GET ALL CALL FEEDBACK FOR A CANDIDATE
# ------------------------------------------------------------------
@router.get("/candidates/{candidate_id}/call-feedback")
def get_candidate_call_feedback(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Get all call feedback entries for a candidate"""
    
    # Validate candidate exists
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == candidate_id
    ).first()
    
    if not candidate:
        raise HTTPException(404, "Candidate not found")
    
    feedbacks = db.query(models.CallFeedback).filter(
        models.CallFeedback.candidate_id == candidate_id
    ).order_by(models.CallFeedback.created_at.desc()).all()
    
    return {
        "candidate_id": candidate_id,
        "feedbacks": [
            {
                "id": fb.id,
                "candidate_id": fb.candidate_id,
                "recruiter_id": fb.recruiter_id,
                "call_type": fb.call_type,
                "call_date": fb.call_date,
                "call_duration": fb.call_duration,
                "call_mode": fb.call_mode,
                "ratings": fb.ratings,
                "salary_alignment": fb.salary_alignment,
                "strengths": fb.strengths,
                "concerns": fb.concerns,
                "additional_notes": fb.additional_notes,
                "candidate_intent": fb.candidate_intent,
                "decision": fb.decision,
                "rejection_reason": fb.rejection_reason,
                "next_actions": fb.next_actions,
                "is_draft": fb.is_draft,
                "created_at": fb.created_at,
                "updated_at": fb.updated_at,
            }
            for fb in feedbacks
        ]
    }


# ------------------------------------------------------------------
# 📖 GET SINGLE CALL FEEDBACK
# ------------------------------------------------------------------
@router.get("/call-feedback/{feedback_id}")
def get_call_feedback(
    feedback_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Get a specific call feedback entry"""
    
    feedback = db.query(models.CallFeedback).filter(
        models.CallFeedback.id == feedback_id
    ).first()
    
    if not feedback:
        raise HTTPException(404, "Call feedback not found")
    
    return {
        "id": feedback.id,
        "candidate_id": feedback.candidate_id,
        "recruiter_id": feedback.recruiter_id,
        "call_type": feedback.call_type,
        "call_date": feedback.call_date,
        "call_duration": feedback.call_duration,
        "call_mode": feedback.call_mode,
        "ratings": feedback.ratings,
        "salary_alignment": feedback.salary_alignment,
        "strengths": feedback.strengths,
        "concerns": feedback.concerns,
        "additional_notes": feedback.additional_notes,
        "candidate_intent": feedback.candidate_intent,
        "decision": feedback.decision,
        "rejection_reason": feedback.rejection_reason,
        "next_actions": feedback.next_actions,
        "is_draft": feedback.is_draft,
        "created_at": feedback.created_at,
        "updated_at": feedback.updated_at,
    }


# ------------------------------------------------------------------
# ✏️ UPDATE CALL FEEDBACK
# ------------------------------------------------------------------
@router.put("/call-feedback/{feedback_id}")
def update_call_feedback(
    feedback_id: str,
    payload: CallFeedbackUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Update an existing call feedback entry"""
    
    feedback = db.query(models.CallFeedback).filter(
        models.CallFeedback.id == feedback_id
    ).first()
    
    if not feedback:
        raise HTTPException(404, "Call feedback not found")
    
    # Validate decision if provided
    if payload.decision:
        valid_decisions = ["Proceed to Next Round", "Hold / Revisit Later", "Reject", "Needs Another Call"]
        if payload.decision not in valid_decisions:
            raise HTTPException(400, f"Invalid decision. Must be one of: {valid_decisions}")
        
        # If decision is Reject, rejection_reason is required
        if payload.decision == "Reject" and not payload.rejection_reason:
            raise HTTPException(400, "Rejection reason is required when decision is 'Reject'")
    
    # Update fields
    if payload.call_type:
        feedback.call_type = payload.call_type
    if payload.call_date:
        feedback.call_date = payload.call_date
    if payload.call_duration is not None:
        feedback.call_duration = payload.call_duration
    if payload.call_mode:
        feedback.call_mode = payload.call_mode
    if payload.ratings:
        feedback.ratings = payload.ratings
    if payload.salary_alignment:
        feedback.salary_alignment = payload.salary_alignment
    if payload.strengths is not None:
        feedback.strengths = payload.strengths
    if payload.concerns is not None:
        feedback.concerns = payload.concerns
    if payload.additional_notes is not None:
        feedback.additional_notes = payload.additional_notes
    if payload.candidate_intent is not None:
        feedback.candidate_intent = payload.candidate_intent
    if payload.decision:
        feedback.decision = payload.decision
    if payload.rejection_reason is not None:
        feedback.rejection_reason = payload.rejection_reason
    if payload.next_actions is not None:
        feedback.next_actions = payload.next_actions
    if payload.is_draft is not None:
        feedback.is_draft = payload.is_draft
    
    feedback.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(feedback)
    
    return {
        "id": feedback.id,
        "candidate_id": feedback.candidate_id,
        "recruiter_id": feedback.recruiter_id,
        "call_type": feedback.call_type,
        "call_date": feedback.call_date,
        "call_duration": feedback.call_duration,
        "call_mode": feedback.call_mode,
        "ratings": feedback.ratings,
        "salary_alignment": feedback.salary_alignment,
        "strengths": feedback.strengths,
        "concerns": feedback.concerns,
        "additional_notes": feedback.additional_notes,
        "candidate_intent": feedback.candidate_intent,
        "decision": feedback.decision,
        "rejection_reason": feedback.rejection_reason,
        "next_actions": feedback.next_actions,
        "is_draft": feedback.is_draft,
        "created_at": feedback.created_at,
        "updated_at": feedback.updated_at,
        "message": "Call feedback updated successfully"
    }


# ------------------------------------------------------------------
# 🗑️ DELETE CALL FEEDBACK
# ------------------------------------------------------------------
@router.delete("/call-feedback/{feedback_id}")
def delete_call_feedback(
    feedback_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    """Delete a call feedback entry"""
    
    feedback = db.query(models.CallFeedback).filter(
        models.CallFeedback.id == feedback_id
    ).first()
    
    if not feedback:
        raise HTTPException(404, "Call feedback not found")
    
    db.delete(feedback)
    db.commit()
    
    return {"message": "Call feedback deleted successfully"}
