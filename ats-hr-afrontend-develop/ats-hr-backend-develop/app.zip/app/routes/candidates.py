# app/routes/candidates.py

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime
import os
import uuid
import json
from fastapi.responses import FileResponse
from sqlalchemy import func


from app.db import get_db
from app import models, schemas
from app.ai_core import (
    parse_resume,
    generate_candidate_embedding,
    calculate_fit_score,
    generate_fit_explanation,
    add_to_faiss_index,
)
from app.auth import get_current_user
from app.permissions import require_permission
from app.utils.role_check import allow_user

# Import system settings
from app.models import SystemSettings

router = APIRouter(prefix="/v1/candidates", tags=["Admin Candidates"])
UPLOAD_DIR = "uploads/resumes"
os.makedirs(UPLOAD_DIR, exist_ok=True)


# ============================================================
# ⭐ HELPER — Generate Candidate ID {ORG}-C-0001
# ============================================================
def generate_candidate_public_id_from_org(db: Session, org_code: str) -> str:

    if not org_code or not isinstance(org_code, str):
        org_code = "ORG"

    org_code = org_code.strip().upper()
    if len(org_code) != 3 or not org_code.isalpha():
        org_code = "ORG"

    prefix = f"{org_code}-C-"

    existing_ids = (
        db.query(models.Candidate.public_id)
        .filter(models.Candidate.public_id.like(f"{prefix}%"))
        .all()
    )

    max_num = 0
    for (pid,) in existing_ids:
        try:
            num = int(pid.replace(prefix, ""))
            max_num = max(max_num, num)
        except:
            continue

    next_num = max_num + 1

    return f"{prefix}{next_num:04d}"




# ============================================================
# ⭐ HELPER — Normalize candidate for response
# ============================================================
def normalize_candidate(candidate: models.Candidate):
    """
    Converts AI / parsed fields into frontend-safe primitives
    """

    if hasattr(candidate, "education") and isinstance(candidate.education, dict):
        candidate.education = candidate.education.get("raw")

    if hasattr(candidate, "experience") and isinstance(candidate.experience, dict):
        candidate.experience = candidate.experience.get("raw")

    if hasattr(candidate, "skills") and isinstance(candidate.skills, dict):
        candidate.skills = candidate.skills.get("raw")

    return candidate

@router.get("")
@require_permission("candidates", "view")
async def list_candidates(
    status: Optional[str] = None,
    source: Optional[str] = None,
    q: Optional[str] = None,
    applied_job: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    allow_user(current_user)

    query = (
        db.query(
            models.Candidate,
            func.max(models.Job.title).label("job_title")
        )
        # ✅ LEFT JOIN so bulk candidates without jobs are included
        .outerjoin(
            models.JobApplication,
            models.JobApplication.candidate_id == models.Candidate.id
        )
        .outerjoin(
            models.Job,
            models.Job.id == models.JobApplication.job_id
        )
        .filter(models.Candidate.merged_into_id.is_(None))
    )

    # ✅ Intake-visible statuses
    ALLOWED_INTAKE_STATUSES = ["new", "screening", "forwarded", "verified"]

    if status:
        query = query.filter(models.Candidate.status == status)
    else:
        query = query.filter(
            models.Candidate.status.in_(ALLOWED_INTAKE_STATUSES)
        )

    if source:
        query = query.filter(
            func.lower(models.Candidate.source) == source.lower()
        )

    if q:
        like = f"%{q}%"
        query = query.filter(
            models.Candidate.full_name.ilike(like) |
            models.Candidate.email.ilike(like)
        )

    # Applied job filter (by job title or job id)
    if applied_job:
        job_like = f"%{applied_job}%"
        query = query.filter(
            (models.Job.title.ilike(job_like)) |
            (models.Job.id == applied_job)
        )

    results = (
        query
        .group_by(models.Candidate.id)
        .order_by(models.Candidate.created_at.desc())
        .all()
    )

    response = []
    for cand, job_title in results:
        c = normalize_candidate(cand)
        c.job_title = job_title or "—"
        response.append(c)

    return response


@router.get("/pool", response_model=List[schemas.CandidateResponse])
@require_permission("candidates", "view")
async def candidate_pool(
    q: Optional[str] = None,
    classification: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    allow_user(current_user)

    query = db.query(models.Candidate).filter(
        models.Candidate.merged_into_id.is_(None)
    )


    if q:
        like = f"%{q}%"
        query = query.filter(
            models.Candidate.full_name.ilike(like) |
            models.Candidate.email.ilike(like)
        )

    if classification:
        query = query.filter(models.Candidate.classification == classification)

    candidates = query.order_by(models.Candidate.created_at.desc()).all()
    return [normalize_candidate(c) for c in candidates]



# ============================================================
# GET SINGLE CANDIDATE
@router.get("/{candidate_id}", response_model=schemas.CandidateResponse)
@require_permission("candidates", "view")
async def get_candidate(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == candidate_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")

    # 🔁 Redirect merged → primary
    if candidate.merged_into_id:
        candidate = db.query(models.Candidate).filter(
            models.Candidate.id == candidate.merged_into_id
        ).first()

    return normalize_candidate(candidate)


# ============================================================
# RESUME VERSION HISTORY
# ============================================================
@router.get("/{candidate_id}/resume/versions")
@require_permission("candidates", "view")
async def admin_resume_versions(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    allow_user(current_user)

    c = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not c:
        raise HTTPException(404, "Candidate not found")

    return c.resume_versions or []


# ============================================================
# RESTORE RESUME VERSION
# ============================================================
@router.post("/{candidate_id}/resume/restore/{version_id}")
@require_permission("candidates", "update")
async def restore_resume(
    candidate_id: str,
    version_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    allow_user(current_user)

    c = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not c:
        raise HTTPException(404, "Candidate not found")

    match = [v for v in (c.resume_versions or []) if v["version_id"] == version_id]
    if not match:
        raise HTTPException(404, "Version not found")

    c.resume_url = match[0]["url"]
    c.parsed_resume = match[0]["parsed_snapshot"]
    c.last_resume_update = datetime.utcnow()

    db.commit()

    return {"message": "Version restored"}

# ============================================================
# FORWARD PROFILE TO ANOTHER USER
# ============================================================
@router.post("/{candidate_id}/forward")
@require_permission("candidates", "update")
async def forward_profile(
    candidate_id: str,
    data: schemas.ForwardProfileRequest,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    allow_user(current_user)

    c = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not c:
        raise HTTPException(404, "Candidate not found")

    user = db.query(models.User).filter(models.User.id == data.forwarded_to_user_id).first()
    if not user:
        raise HTTPException(404, "Target user not found")

    c.forwarded_to = user.username
    c.forward_note = data.note
    c.forwarded_at = datetime.utcnow()
    c.status = "forwarded"

    db.commit()

    return {"message": "Profile forwarded successfully"}


# ============================================================
# UPDATE CANDIDATE STATUS
# ============================================================
@router.put("/{candidate_id}/status")
@require_permission("candidates", "update")
async def update_status(
    candidate_id: str,
    status: str = Form(...),
    note: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    allow_user(current_user)

    c = db.query(models.Candidate).filter(models.Candidate.id == candidate_id).first()
    if not c:
        raise HTTPException(404, "Candidate not found")

    c.status = status

    timeline = models.CandidateTimeline(
        candidate_id=candidate_id,
        status=status,
        note=note,
        user_id=current_user["id"]
    )

    db.add(timeline)
    db.commit()

    return {"message": "Status updated successfully"}


# ============================================================
# CANDIDATE STATUS TIMELINE
# ============================================================
@router.get("/{candidate_id}/timeline", response_model=List[schemas.CandidateTimelineResponse])
@require_permission("candidates", "view")
async def get_timeline(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    allow_user(current_user)

    events = (
        db.query(models.CandidateTimeline)
        .filter(models.CandidateTimeline.candidate_id == candidate_id)
        .order_by(models.CandidateTimeline.created_at.desc())
        .all()
    )

    return [
        schemas.CandidateTimelineResponse(
            id=e.id,
            status=e.status,
            note=e.note,
            by=e.user.username if e.user else None,
            created_at=e.created_at
        )
        for e in events
    ]


# ============================================================
# ADD ADMIN NOTE TO CANDIDATE
# ============================================================
@router.post("/{candidate_id}/notes")
def add_candidate_note(
    candidate_id: str,
    payload: dict,
    db: Session = Depends(get_db),
    current=Depends(get_current_user)
):
    from app.models import Candidate, CandidateNote, Notification

    candidate = db.query(Candidate).filter(Candidate.id == candidate_id).first()
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")

    note_text = payload.get("note")
    if not note_text:
        raise HTTPException(status_code=400, detail="Note is required")

    note = CandidateNote(
        candidate_id=candidate_id,
        note=note_text,
        author_id=current.get("id")
    )

    db.add(note)
    db.commit()
    db.refresh(note)

    # 🔥 Candidate Notification Create
    notification = Notification(
        candidate_id=candidate_id,
        title="New Update From Admin",
        message=note_text,
        type="admin_note"
    )

    db.add(notification)
    db.commit()

    return {
        "message": "Note added successfully and notification sent",
        "note_id": note.id
    }



# ============================================================
# SEND BULK EMAIL TO MULTIPLE CANDIDATES
# ============================================================
@router.post("/email/send")
@require_permission("candidates", "update")
async def bulk_email(
    subject: str = Form(...),
    message_body: str = Form(...),
    candidate_ids: List[str] = Form(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):

    allow_user(current_user)

    candidates = db.query(models.Candidate).filter(models.Candidate.id.in_(candidate_ids)).all()
    if not candidates:
        raise HTTPException(404, "No candidates found")

    sent = []

    for c in candidates:
        logs = c.email_logs or []
        logs.append({
            "subject": subject,
            "body": message_body,
            "sent_at": datetime.utcnow().isoformat(),
            "sent_by": current_user["id"]
        })
        c.email_logs = logs
        sent.append(c.email)

    db.commit()

    return {
        "message": "Emails successfully sent",
        "sent_to": sent
    }


@router.get("/{candidate_id}/resume/download")
@require_permission("candidates", "view")
async def download_resume(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    allow_user(current_user)

    candidate = (
        db.query(models.Candidate)
        .filter(models.Candidate.id == candidate_id)
        .first()
    )

    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")

    if not candidate.resume_url:
        raise HTTPException(status_code=404, detail="Resume not uploaded")

    file_path = candidate.resume_url

    if not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="Resume file missing on server")

    filename = os.path.basename(file_path)

    return FileResponse(
        path=file_path,
        filename=filename,
        media_type="application/octet-stream"
    )


# ============================================================
# MERGE MULTIPLE CANDIDATES
# ============================================================
# ============================================================
# MERGE CANDIDATES
@router.post("/merge")
@require_permission("candidates", "update")
async def merge_candidates(
    data: schemas.CandidateMergeRequest,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    allow_user(current_user)

    if not data.candidate_ids or len(data.candidate_ids) < 2:
        raise HTTPException(400, "At least 2 candidates required")

    candidates = (
        db.query(models.Candidate)
        .filter(
            models.Candidate.id.in_(data.candidate_ids),
            models.Candidate.merged_into_id.is_(None)
        )
        .order_by(models.Candidate.created_at.desc())
        .all()
    )

    if len(candidates) < 2:
        raise HTTPException(404, "Candidates not found")

    # ✅ PRIMARY = most recently updated
    primary = candidates[0]
    duplicates = candidates[1:]

    for dup in duplicates:
        # 🔥 Always keep latest real data
        if dup.phone:
            primary.phone = dup.phone
        if dup.resume_url:
            primary.resume_url = dup.resume_url
        if dup.skills:
            primary.skills = dup.skills
        if dup.education:
            primary.education = dup.education
        if dup.experience_years:
            primary.experience_years = dup.experience_years

        # 🔁 Move relations
        for app in dup.applications:
            app.candidate_id = primary.id
        for note in dup.notes:
            note.candidate_id = primary.id
        for event in dup.timeline_events:
            event.candidate_id = primary.id

        # 🔒 Lock duplicate
        dup.status = "merged"
        dup.merged_into_id = primary.id

    db.commit()

    return {
        "message": "Candidates merged successfully",
        "primary_candidate_id": primary.id
    }



@router.patch("/{candidate_id}/classification")
@router.put("/{candidate_id}/classification")
@require_permission("candidates", "update")
async def update_candidate_classification(
    candidate_id: str,
    data: schemas.CandidateClassificationUpdate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    allow_user(current_user)

    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == candidate_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")

    if candidate.merged_into_id:
        raise HTTPException(
            status_code=400,
            detail="Merged candidate cannot be modified"
        )

    candidate.classification = data.classification
    db.commit()

    return {
        "message": "Classification updated",
        "classification": candidate.classification
    }

@router.put("/{candidate_id}/verify")
@require_permission("candidates", "update")
def verify_candidate(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == candidate_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")

    if candidate.merged_into_id:
        raise HTTPException(
            status_code=400,
            detail="Merged candidate cannot be verified"
        )

    if candidate.status in ["verified", "converted"]:
        raise HTTPException(
            status_code=400,
            detail=f"Candidate already {candidate.status}"
        )

    candidate.status = "verified"

    timeline = models.CandidateTimeline(
        candidate_id=candidate.id,
        status="verified",
        note="Verified by recruiter",
        user_id=current_user["id"]
    )

    db.add(timeline)
    db.commit()

    return {
        "message": "Candidate verified successfully",
        "candidateId": candidate.id,
        "status": candidate.status
    }

@router.put("/{candidate_id}/status")
@require_permission("candidates", "update")
async def update_candidate_status(
    candidate_id: str,
    status: str = Form(...),
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    allow_user(current_user)

    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == candidate_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")

    if candidate.merged_into_id:
        raise HTTPException(
            status_code=400,
            detail="Merged candidate is read-only"
        )

    if status != "verified":
        raise HTTPException(
            status_code=400,
            detail="Only 'verified' status is allowed"
        )

    candidate.status = "verified"

    timeline = models.CandidateTimeline(
        candidate_id=candidate.id,
        status="verified",
        note="Verified by recruiter",
        user_id=current_user["id"]
    )

    db.add(timeline)
    db.commit()

    return {
        "message": "Candidate verified successfully",
        "candidateId": candidate.id,
        "status": candidate.status
    }
