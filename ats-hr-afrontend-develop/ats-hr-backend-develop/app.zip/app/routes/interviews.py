from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session, joinedload
from datetime import datetime, timedelta
from typing import Optional
from pydantic import BaseModel

from app.db import get_db
from app import models, schemas
from app.auth import get_current_user
from app.permissions import require_permission
from app.ai_core import AIInterviewer, generate_video_interview_questions
router = APIRouter(prefix="/v1/interviews", tags=["Interviews"])

# In-memory AI interview sessions
active_sessions: dict[str, AIInterviewer] = {}

############################################
# 1️⃣ Create Interview 🔒
############################################
@router.post(
    "",
    response_model=schemas.InterviewResponse,
    dependencies=[Depends(get_current_user)]
)
def create_interview(
    data: schemas.InterviewCreate,
    db: Session = Depends(get_db)
):
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == data.candidate_id
    ).first()

    job = db.query(models.Job).filter(
        models.Job.id == data.job_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")
    if not job:
        raise HTTPException(404, "Job not found")

    interview = models.Interview(
        candidate_id=data.candidate_id,
        job_id=data.job_id,
        scheduled_at=data.scheduled_at,
        mode=data.mode,
        meeting_link=data.meeting_link,
        status="scheduled"
    )

    db.add(interview)
    db.commit()
    db.refresh(interview)
    return interview

############################################
# 2️⃣ Get All Interviews 🔒 (FIXED)
############################################
@router.get("")
def list_interviews(
    assigned_to: str = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    query = db.query(models.Interview)

    # ---------- Candidate ke liye sirf uski interviews ----------
    if current_user.get("role") == "candidate":
        
        candidate_id = None
        
        # Case 1: if backend directly returns id
        if current_user.get("id"):
            candidate_id = current_user["id"]

        # Case 2: if backend keeps nested candidate
        elif current_user.get("candidate") and current_user["candidate"].get("id"):
            candidate_id = current_user["candidate"]["id"]

        if candidate_id:
            query = query.join(
                models.CandidateSubmission,
                models.Interview.submission_id == models.CandidateSubmission.id
            ).filter(
                models.CandidateSubmission.candidate_id == candidate_id
            )

    interviews = query.all()

    return interviews



############################################
# 3️⃣ Interview Logs (Completed) 🔒
############################################
@router.get(
    "/logs",
    response_model=list[schemas.InterviewLogListResponse],
    dependencies=[Depends(get_current_user)]
)
def interview_logs(db: Session = Depends(get_db)):
    return (
        db.query(models.Interview)
        .filter(models.Interview.status == "completed")
        .order_by(models.Interview.completed_at.desc())
        .all()
    )
############################################
# 4️⃣ Get Interview Detail 🔒
############################################
@router.get(
    "/{id}",
    response_model=schemas.InterviewDetailResponse,
    dependencies=[Depends(get_current_user)]
)
def get_interview(id: str, db: Session = Depends(get_db)):
    interview = (
        db.query(models.Interview)
        .filter(models.Interview.id == id)
        .first()
    )

    if not interview:
        raise HTTPException(404, "Interview not found")

    return interview

############################################
# 5️⃣ Update Interview 🔒
############################################
@router.put("/{id}", dependencies=[Depends(get_current_user)])
def update_interview(
    id: str,
    data: schemas.InterviewUpdate,
    db: Session = Depends(get_db)
):
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    for key, value in data.dict(exclude_unset=True).items():
        setattr(interview, key, value)

    db.commit()
    db.refresh(interview)
    return interview

##########################################################
#               AI Interview Flow 🔒
##########################################################

############################################
# 6️⃣ Start AI Interview
############################################
@router.post("/{id}/start", dependencies=[Depends(get_current_user)])
def start_ai_interview(
    id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    # 🚨 Only candidate allowed
    if current_user.get("role") != "candidate":
        raise HTTPException(403, "Only candidates can start interview")

    # ---------- SAFE CANDIDATE ID EXTRACTION ----------
    cand_id = (
        current_user.get("id")
        or current_user.get("candidate_id")
        or current_user.get("candidate", {}).get("id")
    )

    if not cand_id:
        raise HTTPException(400, "Candidate ID not found in token")

    if interview.submission.candidate_id != cand_id:
        raise HTTPException(403, "You are not allowed to start this interview")
    # ---------------------------------------------------

    job = interview.submission.job
    resume_text = getattr(interview.submission.candidate, "resume_text", None)

    interviewer = AIInterviewer(
        job_data={
            "title": job.title,
            "skills": job.skills or [],
            "description": job.description or ""
        },
        resume_text=resume_text
    )

    active_sessions[id] = interviewer

    return {
        "session_id": id,
        "question": interviewer.get_next_question(),
        "message": "AI interview started"
    }

############################################
# 7️⃣ Get Next Question
############################################
@router.get("/{id}/question", dependencies=[Depends(get_current_user)])
def ai_next_question(id: str):
    interviewer = active_sessions.get(id)
    if not interviewer:
        raise HTTPException(400, "Interview session not found")

    q = interviewer.get_next_question()
    return q or {"message": "Interview finished"}

############################################
# 8️⃣ Submit Answer
############################################
@router.post("/{id}/answer", dependencies=[Depends(get_current_user)])
def ai_answer(id: str, payload: schemas.InterviewAnswerRequest):
    interviewer = active_sessions.get(id)
    if not interviewer:
        raise HTTPException(400, "AI interview not started")

    return interviewer.submit_answer(payload.answer)

############################################
# 9️⃣ Complete Interview
############################################
@router.post("/{id}/complete", dependencies=[Depends(get_current_user)])
def complete_interview(id: str, db: Session = Depends(get_db)):
    interviewer = active_sessions.get(id)
    if not interviewer:
        raise HTTPException(400, "Interview session not found")

    final_score = interviewer.get_final_score()

    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    interview.status = "completed"
    interview.overall_ai_score = final_score
    interview.transcript = interviewer.conversation_history
    interview.completed_at = datetime.utcnow()

    db.commit()

    video_questions = generate_video_interview_questions({
        "title": interview.job.title,
        "skills": interview.job.skills or [],
        "description": interview.job.description or ""
    })

    video_interview = models.AIVideoInterview(
        candidate_id=interview.submission.candidate_id,
        job_id=interview.submission.job_id,
        questions=video_questions,
        recording_enabled=True,
        status="scheduled"
    )

    db.add(video_interview)
    db.commit()

    active_sessions.pop(id, None)

    return {
        "message": "Interview completed",
        "final_score": final_score
    }


##########################################################
#          Interview Feedback & Rescheduling 🔒
##########################################################

############################################
# 🔟 Add Interview Feedback
############################################
class InterviewFeedbackRequest(BaseModel):
    feedback_score: Optional[float] = None
    feedback_comments: Optional[str] = None
    rating_technical: Optional[int] = None
    rating_communication: Optional[int] = None
    rating_cultural_fit: Optional[int] = None


@router.post("/{id}/feedback", dependencies=[Depends(get_current_user)])
def add_interview_feedback(
    id: str,
    feedback: InterviewFeedbackRequest,
    db: Session = Depends(get_db)
):
    """Add or update interview feedback and ratings."""
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    # Update feedback fields
    if feedback.feedback_score is not None:
        interview.overall_ai_score = feedback.feedback_score
    if feedback.feedback_comments is not None:
        interview.transcript = feedback.feedback_comments
    if feedback.rating_technical is not None:
        interview.rating_technical = feedback.rating_technical
    if feedback.rating_communication is not None:
        interview.rating_communication = feedback.rating_communication
    if feedback.rating_cultural_fit is not None:
        interview.rating_cultural_fit = feedback.rating_cultural_fit

    interview.status = "completed"
    interview.completed_at = datetime.utcnow()

    db.commit()
    db.refresh(interview)

    return {
        "message": "Feedback saved successfully",
        "interview_id": id,
        "score": interview.overall_ai_score
    }


############################################
# 1️⃣1️⃣ Reschedule Interview
############################################
class RescheduleRequest(BaseModel):
    scheduled_date: datetime
    reason: Optional[str] = None


@router.post("/{id}/reschedule", dependencies=[Depends(get_current_user)])
def reschedule_interview(
    id: str,
    data: RescheduleRequest,
    db: Session = Depends(get_db)
):
    """Reschedule an interview to a new date/time."""
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    if interview.status == "completed":
        raise HTTPException(400, "Cannot reschedule completed interview")

    # Update scheduled time
    old_date = interview.scheduled_at
    interview.scheduled_at = data.scheduled_date
    interview.status = "rescheduled"

    db.commit()
    db.refresh(interview)

    return {
        "message": "Interview rescheduled",
        "interview_id": id,
        "old_date": old_date,
        "new_date": interview.scheduled_at,
        "reason": data.reason or "No reason provided"
    }


############################################
# 1️⃣2️⃣ Cancel Interview
############################################
@router.post("/{id}/cancel", dependencies=[Depends(get_current_user)])
def cancel_interview(id: str, db: Session = Depends(get_db)):
    """Cancel an interview."""
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    interview.status = "cancelled"
    db.commit()

    return {"message": "Interview cancelled successfully"}


############################################
# 1️⃣3️⃣ Get Upcoming Interviews for Candidate
############################################
@router.get("/candidate/{candidate_id}/upcoming")
def get_candidate_upcoming_interviews(
    candidate_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get upcoming interviews for a specific candidate."""
    now = datetime.utcnow()
    upcoming = (
        db.query(models.Interview)
        .join(models.CandidateSubmission, models.Interview.submission_id == models.CandidateSubmission.id)
        .filter(
            models.CandidateSubmission.candidate_id == candidate_id,
            models.Interview.scheduled_at >= now,
            models.Interview.status.in_(["scheduled", "rescheduled"])
        )
        .order_by(models.Interview.scheduled_at)
        .all()
    )
    return upcoming


############################################
# 1️⃣4️⃣ Get Interview Statistics
############################################
@router.get("/job/{job_id}/stats")
def get_job_interview_stats(
    job_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get interview statistics for a job."""
    interviews = (
        db.query(models.Interview)
        .filter(models.Interview.job_id == job_id)
        .all()
    )

    total = len(interviews)
    completed = len([i for i in interviews if i.status == "completed"])
    scheduled = len([i for i in interviews if i.status == "scheduled"])
    cancelled = len([i for i in interviews if i.status == "cancelled"])

    avg_score = (
        sum([i.overall_ai_score for i in interviews if i.overall_ai_score])
        / len([i for i in interviews if i.overall_ai_score])
        if any(i.overall_ai_score for i in interviews)
        else 0
    )

    return {
        "job_id": job_id,
        "total_interviews": total,
        "completed": completed,
        "scheduled": scheduled,
        "cancelled": cancelled,
        "average_score": round(avg_score, 1),
        "completion_rate": round((completed / total * 100) if total > 0 else 0, 1),
    }


############################################
# 1️⃣5️⃣ Submit Interview Feedback (Candidate)
############################################
@router.post("/{id}/feedback", dependencies=[Depends(get_current_user)])
def submit_interview_feedback(
    id: str,
    feedback: schemas.InterviewFeedbackRequest,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Submit feedback after interview completion (candidate portal)."""
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    # Get candidate ID from current user
    candidate_id = (
        current_user.get("id") 
        or current_user.get("candidate_id") 
        or current_user.get("candidate", {}).get("id")
    )

    if not candidate_id:
        raise HTTPException(400, "Candidate ID not found")

    # Verify candidate owns this interview
    if interview.submission.candidate_id != candidate_id:
        raise HTTPException(403, "Unauthorized to submit feedback for this interview")

    # Check if feedback already exists
    existing_feedback = db.query(models.InterviewFeedback).filter(
        models.InterviewFeedback.interview_id == id
    ).first()

    if existing_feedback:
        # Update existing feedback
        existing_feedback.rating = feedback.rating
        existing_feedback.experience_feedback = feedback.experience_feedback
        existing_feedback.ease_of_use = feedback.ease_of_use
        existing_feedback.comments = feedback.comments
        existing_feedback.submitted_at = datetime.utcnow()
        db.commit()
        db.refresh(existing_feedback)
        return existing_feedback
    else:
        # Create new feedback
        interview_feedback = models.InterviewFeedback(
            interview_id=id,
            candidate_id=candidate_id,
            rating=feedback.rating,
            experience_feedback=feedback.experience_feedback,
            ease_of_use=feedback.ease_of_use,
            comments=feedback.comments
        )
        db.add(interview_feedback)
        db.commit()
        db.refresh(interview_feedback)
        return interview_feedback


############################################
# 1️⃣6️⃣ Get Interview Feedback
############################################
@router.get("/{id}/feedback", response_model=schemas.InterviewFeedbackResponse)
def get_interview_feedback(
    id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get feedback for a specific interview."""
    feedback = db.query(models.InterviewFeedback).filter(
        models.InterviewFeedback.interview_id == id
    ).first()

    if not feedback:
        raise HTTPException(404, "Interview feedback not found")

    return feedback


############################################
# 1️⃣7️⃣ List Interview Feedback (Recruiter/Admin)
############################################
@router.get("/job/{job_id}/feedbacks")
def get_job_interview_feedbacks(
    job_id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all feedback for interviews of a specific job (Recruiter/Admin)."""
    feedbacks = (
        db.query(models.InterviewFeedback)
        .join(models.Interview, models.InterviewFeedback.interview_id == models.Interview.id)
        .filter(models.Interview.submission.job_id == job_id)
        .all()
    )
    return feedbacks


############################################
# 1️⃣8️⃣ Schedule Interview (Recruiter)
############################################
class InterviewScheduleRequest(BaseModel):
    candidate_id: str
    job_id: str
    interview_type: str  # "ai_chat", "video", "in_person"
    scheduled_at: datetime
    meeting_link: Optional[str] = None  # For video interviews
    location: Optional[str] = None  # For in-person interviews
    instructions: Optional[str] = None
    notes: Optional[str] = None


@router.post("/schedule", dependencies=[Depends(get_current_user)])
def schedule_interview(
    data: InterviewScheduleRequest,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Schedule an interview for a candidate."""
    # Verify candidate and job exist
    candidate = db.query(models.Candidate).filter(
        models.Candidate.id == data.candidate_id
    ).first()
    
    job = db.query(models.Job).filter(
        models.Job.id == data.job_id
    ).first()

    if not candidate:
        raise HTTPException(404, "Candidate not found")
    if not job:
        raise HTTPException(404, "Job not found")

    # Get or create submission
    submission = db.query(models.CandidateSubmission).filter(
        models.CandidateSubmission.candidate_id == data.candidate_id,
        models.CandidateSubmission.job_id == data.job_id
    ).first()

    if not submission:
        # Create submission if doesn't exist
        submission = models.CandidateSubmission(
            candidate_id=data.candidate_id,
            job_id=data.job_id,
            recruiter_id=current_user.get("id"),
            match_score=0,
            status="interview"
        )
        db.add(submission)
        db.commit()
        db.refresh(submission)

    # Create interview
    interview = models.Interview(
        submission_id=submission.id,
        mode=data.interview_type,
        scheduled_at=data.scheduled_at,
        status="scheduled",
        meeting_link=data.meeting_link,
        notes=data.notes
    )
    
    db.add(interview)
    db.commit()
    db.refresh(interview)

    return {
        "message": "Interview scheduled successfully",
        "interview_id": interview.id,
        "scheduled_at": interview.scheduled_at,
        "interview_type": data.interview_type
    }


############################################
# 1️⃣9️⃣ Get Recruiter Dashboard - All Scheduled Interviews
############################################
@router.get("/recruiter/dashboard/interviews")
def get_recruiter_interviews(
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Get all interviews assigned to a recruiter."""
    if current_user.get("role") != "recruiter":
        raise HTTPException(403, "Only recruiters can access this")

    recruiter_id = current_user.get("id")

    query = db.query(models.Interview).join(
        models.CandidateSubmission,
        models.Interview.submission_id == models.CandidateSubmission.id
    ).filter(
        models.CandidateSubmission.recruiter_id == recruiter_id
    )

    if status:
        query = query.filter(models.Interview.status == status)

    interviews = query.order_by(
        models.Interview.scheduled_at.desc()
    ).all()

    return interviews


############################################
# 2️⃣0️⃣ Mark Interview as Completed (Recruiter)
############################################
@router.post("/{id}/mark-completed")
def mark_interview_completed(
    id: str,
    db: Session = Depends(get_db),
    current_user = Depends(get_current_user)
):
    """Mark an interview as completed."""
    interview = db.query(models.Interview).filter(
        models.Interview.id == id
    ).first()

    if not interview:
        raise HTTPException(404, "Interview not found")

    interview.status = "completed"
    interview.completed_at = datetime.utcnow()
    db.commit()
    db.refresh(interview)

    return {
        "message": "Interview marked as completed",
        "interview_id": id,
        "completed_at": interview.completed_at
    }


