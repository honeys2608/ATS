from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List

from app.db import get_db
from app import models
from app.auth import get_current_user
from app.permissions import require_permission
import app.schemas as schemas
from app.schemas import SendToClientRequest, AssignRecruiterRequest
from app.routes.jobs import generate_job_id
import secrets
from app.auth import get_password_hash
from app.utils.email import send_email
from app.models import ConsultantType

router = APIRouter(
    prefix="/v1/am",
    tags=["Account Manager"]
)

# ---------------------------------------------------------
# UTIL
# ---------------------------------------------------------
def get_user_id(user: dict):
    return (
        user.get("id")
        or user.get("user_id")
        or user.get("sub")
    )

# ---------------------------------------------------------
# APPROVE REQUIREMENT
# ---------------------------------------------------------
@router.put("/requirements/{req_id}/approve")
def approve_requirement(
    req_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    req = db.query(models.Requirement).filter(
        models.Requirement.id == req_id,
        models.Requirement.account_manager_id == get_user_id(current_user)
    ).first()

    if not req:
        raise HTTPException(404, "Requirement not found or not assigned to you")

    # 🔒 BLOCK RE-APPROVAL
    if req.status != "NEW":
        raise HTTPException(
            status_code=400,
            detail=f"Requirement already processed (current status: {req.status})"
        )

    req.status = "APPROVED"
    req.approved_at = datetime.utcnow()
    req.updated_at = datetime.utcnow()

    db.commit()

    return {
        "message": "Requirement approved",
        "status": req.status
    }

# ---------------------------------------------------------
# ACTIVATE REQUIREMENT → CREATE JOB
# ---------------------------------------------------------
@router.post("/requirements/{req_id}/activate")
def activate_requirement(
    req_id: str,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    req = db.query(models.Requirement).filter(
        models.Requirement.id == req_id,
        models.Requirement.account_manager_id == get_user_id(current_user)
    ).first()

    if not req:
        raise HTTPException(404, "Requirement not found or not assigned to you")

    # 🔒 MUST BE APPROVED FIRST
    if req.status != "APPROVED":
        raise HTTPException(
            status_code=400,
            detail="Requirement must be approved before activation"
        )

    # 🔒 PREVENT DUPLICATE JOB
    if req.job_id:
        raise HTTPException(
            status_code=400,
            detail="Job already exists for this requirement"
        )

    # ✅ SAFE TO CREATE JOB
    job = models.Job(
        client_id=req.client_id,
        job_id=generate_job_id(db),
        title=req.title,
        skills=req.skills.split(",") if isinstance(req.skills, str) else req.skills,
        location=req.location,
        status="active",
        account_manager_id=req.account_manager_id,  # ⭐⭐⭐ MAIN FIX
        created_at=datetime.utcnow()
    )

    db.add(job)
    db.commit()
    db.refresh(job)

    req.job_id = job.id
    req.status = "CONVERTED_TO_JOB"
    req.activated_at = datetime.utcnow()
    req.updated_at = datetime.utcnow()

    db.commit()

    return {
        "message": "Requirement converted to Job successfully",
        "job_uuid": job.id,
        "job_code": job.job_id,
        "job_title": job.title,
        "status": job.status
    }

# ---------------------------------------------------------
# ASSIGN RECRUITER
# ---------------------------------------------------------
@router.post("/assign-recruiter")
def assign_recruiter(
    payload: AssignRecruiterRequest,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    job = db.query(models.Job).filter(
        models.Job.id == payload.job_id
    ).first()

    recruiter = db.query(models.User).filter(
        models.User.id == payload.recruiter_id
    ).first()

    if not job:
        raise HTTPException(404, "Job not found")

    if not recruiter:
        raise HTTPException(404, "Recruiter not found")

    db.execute(
        models.job_recruiters.insert().values(
            job_id=job.id,
            recruiter_id=recruiter.id,
            assigned_at=datetime.utcnow()
        )
    )

    db.commit()

    return {"message": "Recruiter assigned successfully"}

# ---------------------------------------------------------
# VIEW RECRUITER SUBMISSIONS
# ---------------------------------------------------------
@router.get("/recruiter-submissions")
def recruiter_submissions(
    job_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    requirement = db.query(models.Requirement).filter(
        models.Requirement.id == job_id
    ).first()

    if requirement and requirement.job_id:
        job_id = requirement.job_id

    recruiter_rows = (
        db.query(
            models.User.id.label("recruiter_id"),
            models.User.full_name.label("recruiter_name"),
            models.job_recruiters.c.assigned_at
        )
        .join(
            models.job_recruiters,
            models.job_recruiters.c.recruiter_id == models.User.id
        )
        .filter(models.job_recruiters.c.job_id == job_id)
        .all()
    )

    recruiter_map = {
        r.recruiter_id: {
            "name": r.recruiter_name,
            "assigned_at": r.assigned_at
        }
        for r in recruiter_rows
    }

    applications = (
        db.query(models.JobApplication)
        .filter(models.JobApplication.job_id == job_id)
        .all()
    )

    result = []

    if not applications:
        for info in recruiter_map.values():
            result.append({
                "application_id": None,
                "recruiter_name": info["name"],
                "recruiter_assigned_at": info["assigned_at"],
                "candidate_name": None,
                "email": None,
                "status": "NO_SUBMISSION",
                "submitted_at": None,
                "sent_to_client_at": None
            })
        return {"job_id": job_id, "submissions": result}

    for app in applications:
        recruiter_info = recruiter_map.get(app.recruiter_id)

        result.append({
            "application_id": app.id,
            "candidate_name": app.full_name,
            "email": app.email,
            "status": app.status,
            "recruiter_name": recruiter_info["name"] if recruiter_info else "—",
            "recruiter_assigned_at": recruiter_info["assigned_at"] if recruiter_info else None,
            "submitted_at": app.applied_at,
            "sent_to_client_at": app.sent_to_client_at
        })

    return {"job_id": job_id, "submissions": result}

# ---------------------------------------------------------
# SEND CANDIDATES TO CLIENT
# ---------------------------------------------------------
@router.post("/send-to-client")
@require_permission("candidates", "update")
def send_to_client(
    payload: SendToClientRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    job = db.query(models.Job).filter(
        models.Job.id == payload.job_id
    ).first()

    if not job:
        raise HTTPException(404, "Job not found")

    applications = db.query(models.JobApplication).filter(
        models.JobApplication.id.in_(payload.application_ids)
    ).all()

    if not applications:
        raise HTTPException(400, "No valid applications found")

    for app in applications:
        app.status = "sent_to_client"
        app.sent_to_client_at = datetime.utcnow()

    db.commit()

    return {
        "message": "Profiles successfully sent to client",
        "job_id": payload.job_id,
        "total_sent": len(applications)
    }

# ---------------------------------------------------------
# VIEW CLIENT FEEDBACK
# ---------------------------------------------------------
@router.get("/client-feedback")
@require_permission("candidates", "view")
def client_feedback(
    job_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    apps = db.query(models.JobApplication).filter(
        models.JobApplication.job_id == job_id
    ).all()

    return {
        "job_id": job_id,
        "feedback": [
            {
                "application_id": a.id,
                "candidate": a.full_name,
                "status": a.status,
                "client_feedback": getattr(a, "client_feedback", None),
                "decision": getattr(a, "client_decision", None),
            }
            for a in apps
        ]
    }

# ---------------------------------------------------------
# LIST RECRUITERS
# ---------------------------------------------------------
@router.get("/recruiters")
def list_recruiters(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    users = db.query(models.User).filter(
        models.User.role == "recruiter"
    ).all()

    return [
        {
            "id": u.id,
            "full_name": u.full_name,
            "email": u.email
        }
        for u in users
    ]

# ---------------------------------------------------------
# DASHBOARD STATS
# ---------------------------------------------------------
@router.get("/dashboard-stats")
def dashboard_stats(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    am_id = get_user_id(current_user)

    req_ids = db.query(models.Requirement.id).filter(
        models.Requirement.account_manager_id == am_id
    ).subquery()

    job_ids = db.query(models.Job.id).filter(
        models.Job.id == models.Requirement.job_id,
        models.Requirement.id.in_(req_ids)
    ).subquery()

    return {
        "recruiter_submissions": db.query(models.JobApplication).filter(
            models.JobApplication.job_id.in_(job_ids)
        ).count(),

        "sent_to_client": db.query(models.JobApplication).filter(
            models.JobApplication.job_id.in_(job_ids),
            models.JobApplication.status == "sent_to_client"
        ).count(),

        "feedback_pending": db.query(models.JobApplication).filter(
            models.JobApplication.job_id.in_(job_ids),
            models.JobApplication.client_decision == None
        ).count()
    }

# ---------------------------------------------------------
# GET ALL REQUIREMENTS (AM VIEW)
# ---------------------------------------------------------
@router.get("/requirements")
def get_all_requirements(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    reqs = (
        db.query(models.Requirement)
        .filter(models.Requirement.account_manager_id == get_user_id(current_user))
        .order_by(models.Requirement.created_at.desc())
        .all()
    )

    return {
        "requirements": [
            {
                "requirement_code": r.requirement_code,
                "id": r.id,
                "title": r.title,
                "skills": r.skills,
                "location": r.location,
                "budget": r.budget,
                "status": r.status,
                "client_id": r.client_id,
                "job_id": r.job_id,
                "created_at": r.created_at,
                "approved_at": r.approved_at,
                "activated_at": r.activated_at,
            }
            for r in reqs
        ]
    }
# ---------------------------------------------------------
# CONSULTANTS READY FOR ASSIGNMENT (AM VIEW)
@router.get("/ready-for-assignment")
def ready_for_assignment(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    result = []

    # =====================================================
    # 1️⃣ ALREADY CONSULTANTS (Admin / Converted)
    # =====================================================
    consultants = (
        db.query(models.Consultant)
        .outerjoin(models.Candidate, models.Candidate.id == models.Consultant.candidate_id)
        .filter(models.Consultant.status == "available")
        .order_by(models.Consultant.created_at.desc())
        .all()
    )

    for c in consultants:
        result.append({
            "consultant_id": c.id,
            "consultant_name": c.candidate.full_name if c.candidate else None,
            "candidate_name": c.candidate.full_name if c.candidate else None,
            "email": c.candidate.email if c.candidate else None,
            "client_id": c.client_id,
            "type": c.type.value if hasattr(c.type, "value") else c.type,
            "status": c.status,
            "created_at": c.created_at,
        })

    # =====================================================
    # 2️⃣ CLIENT CANDIDATES (HIRED, NOT YET CONSULTANT)
    # =====================================================
    hired_apps = (
        db.query(models.JobApplication)
        .filter(
            models.JobApplication.status == "HIRED",
            models.JobApplication.candidate_id.notin_(
                db.query(models.Consultant.candidate_id)
            )
        )
        .order_by(models.JobApplication.applied_at.desc())

        .all()
    )

    for app in hired_apps:
        result.append({
            "application_id": app.id,
            "candidate_name": app.candidate.full_name if app.candidate else None,
            "email": app.candidate.email if app.candidate else None,
            "job_id": app.job_id,
            "client_id": app.job.client_id if app.job else None,
            "status": "HIRED",
        })

    return result

@router.post("/assign-consultant")
def assign_consultant(
    payload: schemas.ConsultantDeploymentCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    consultant = None
    app = None

    # =====================================================
    # CASE 1️⃣ : ALREADY CONSULTANT → ONLY ASSIGN
    # =====================================================
    if payload.consultantId:
        consultant = db.query(models.Consultant).filter(
            models.Consultant.id == payload.consultantId
        ).first()

        if not consultant:
            raise HTTPException(404, "Consultant not found")

    # =====================================================
    # CASE 2️⃣ : HIRED CANDIDATE → CONVERT + ASSIGN
    # =====================================================
    elif payload.applicationId:
        app = db.query(models.JobApplication).filter(
            models.JobApplication.id == payload.applicationId,
            models.JobApplication.status == "HIRED"
        ).first()

        if not app:
            raise HTTPException(404, "Hired application not found")

        # 🔁 Already converted earlier?
        consultant = db.query(models.Consultant).filter(
            models.Consultant.candidate_id == app.candidate_id
        ).first()

        if not consultant:
            candidate = app.candidate

            if not candidate:
                raise HTTPException(400, "Candidate not found")

            # ---------------------------------------------
            # 🔐 CREATE / FETCH USER
            # ---------------------------------------------
            user = db.query(models.User).filter(
                models.User.email == candidate.email
            ).first()

            temp_password = None

            if not user:
                temp_password = secrets.token_urlsafe(8)
                hashed_password = get_password_hash(temp_password)
                 # ✅ VS CODE CONSOLE LOG
                print("\n==============================")
                print("✅ NEW CONSULTANT USER CREATED")
                print("Email:", candidate.email)
                print("Password:", temp_password)
                print("==============================\n")

                user = models.User(
                    username=candidate.email.split("@")[0],
                    email=candidate.email,
                    password=hashed_password,
                    role="consultant",
                    full_name=candidate.full_name,
                    must_change_password=True,
                    linked_candidate_id=candidate.id
                )
                db.add(user)
                db.commit()
                db.refresh(user)
            else:
                user.role = "consultant"
                user.must_change_password = True
                db.commit()

            # ---------------------------------------------
            # 👨‍💼 CREATE CONSULTANT
            # ---------------------------------------------
            consultant = models.Consultant(
                candidate_id=candidate.id,
                user_id=user.id,
                client_id=payload.clientId,
                consultant_code=f"CONS-{int(datetime.utcnow().timestamp())}",
                type=(
                    ConsultantType.payroll
                    if payload.billingType == "payroll"
                    else ConsultantType.sourcing
                ),
                status="available",
                payroll_ready=False,
                created_at=datetime.utcnow()
            )

            db.add(consultant)
            candidate.status = "converted"
            db.commit()
            db.refresh(consultant)

            # ---------------------------------------------
            # 📧 SEND LOGIN EMAIL (ONLY ON FIRST CREATE)
            # ---------------------------------------------
            if temp_password:
                try:
                    send_email(
                        to=candidate.email,
                        subject="Your Consultant Login Credentials",
                        body=f"""
Hi {candidate.full_name},

Your consultant account has been created.

Login Email: {candidate.email}
Temporary Password: {temp_password}

Please login and change your password.

Regards,
HR Team
"""
                    )
                except Exception as e:
                    print("Email failed:", e)

    else:
        raise HTTPException(
            400,
            "Either consultantId or applicationId is required"
        )

    # =====================================================
    # 🚀 ASSIGN DEPLOYMENT
    # =====================================================
    if consultant.status == "deployed":
        raise HTTPException(400, "Consultant already deployed")

    deployment = models.ConsultantDeployment(
        consultant_id=consultant.id,
        client_id=payload.clientId,
        client_name=payload.clientName,
        role=payload.role,
        start_date=payload.startDate,
        end_date=payload.endDate,
        billing_type=payload.billingType,
        billing_rate=payload.billingRate,
        payout_rate=payload.payoutRate,
        status="active",
        created_at=datetime.utcnow()
    )

    consultant.status = "deployed"

    db.add(deployment)

    if app:
        app.status = "DEPLOYED"

    db.commit()
    db.refresh(deployment)

    return {
        "message": "Consultant converted & assigned successfully"
        if payload.applicationId
        else "Consultant assigned successfully",
        "deployment_id": deployment.id,
        "consultant_id": consultant.id
    }


# ---------------------------------------------------------
# LIST ALL CONSULTANTS (AM VIEW)
# ---------------------------------------------------------
@router.get("/consultants")
def list_consultants_for_am(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user)
):
    am_id = get_user_id(current_user)

    consultants = (
        db.query(models.Consultant)
        .join(models.Candidate, models.Candidate.id == models.Consultant.candidate_id)
        .outerjoin(
            models.ConsultantDeployment,
            models.ConsultantDeployment.consultant_id == models.Consultant.id
        )
        .order_by(models.Consultant.created_at.desc())
        .all()
    )

    return [
        {
            "consultant_id": c.id,
            "candidate_id": c.candidate_id,
            "name": c.candidate.full_name if c.candidate else None,
            "email": c.candidate.email if c.candidate else None,
            "type": c.type.value if hasattr(c.type, "value") else c.type,
            "status": c.status,
            "is_deployed": c.status == "deployed",
            "created_at": c.created_at
        }
        for c in consultants
    ]
