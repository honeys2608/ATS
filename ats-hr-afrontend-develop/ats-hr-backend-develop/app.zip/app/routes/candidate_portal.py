# app/routes/candidate_portal.py

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from datetime import datetime
from typing import List  
import uuid
import os
import pdfplumber
from docx import Document

from app.db import get_db
from app import models, schemas
from app.auth import get_current_user
from app.ai_core import parse_resume, generate_candidate_embedding
from app.models import Notification
from app.schemas import NotificationResponse
from app.validators import (
    validate_location,
    validate_pincode,
    validate_skills,
)
import re

router = APIRouter(prefix="/v1/candidate", tags=["Candidate Portal"])

UPLOAD_DIR = "uploads/resumes"
PHOTO_UPLOAD_DIR = "uploads/candidates/photos"
def is_valid_indian_phone(phone: str) -> bool:
    if not phone:
        return False
    phone = phone.replace(" ", "")
    return bool(re.match(r"^(\+91)?[6-9]\d{9}$", phone))

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PHOTO_UPLOAD_DIR, exist_ok=True)


def calculate_profile_completion(cand: models.Candidate) -> int:
    print("🔥 FRACTIONAL PROFILE COMPLETION LOGIC ACTIVE 🔥")

    def filled(v):
        if isinstance(v, list):
            return len(v) > 0
        return v is not None and str(v).strip() != ""

    # -------- BASIC (25) --------
    basic_fields = [
        cand.full_name,
        cand.email,
        cand.phone,
        cand.current_location,
        cand.city,
        cand.pincode,
    ]
    basic_score = (sum(filled(f) for f in basic_fields) / 6) * 25

    # -------- PROFESSIONAL (25) --------
    professional_fields = [
        cand.skills,
        cand.education,
        cand.experience,
        cand.current_employer,
    ]
    professional_score = (sum(filled(f) for f in professional_fields) / 4) * 25

    # -------- SOCIAL (25) --------
    social_fields = [
        cand.linkedin_url,
        cand.github_url,
        cand.portfolio_url,
        cand.languages_known,
    ]
    social_score = (sum(filled(f) for f in social_fields) / 4) * 25

    # -------- RESUME (25) --------
    resume_score = 25 if filled(cand.resume_url) else 0

    total = basic_score + professional_score + social_score + resume_score
    return round(total)


def create_notification(db, candidate_id, title, message=None, type="info"):
    from app.models import Notification

    notification = Notification(
        candidate_id=candidate_id,
        title=title,
        message=message,
        type=type
    )

    db.add(notification)
    db.commit()
    db.refresh(notification)
    return notification



# -----------------------------------------------------------
# UPLOAD RESUME + PARSE (NO DB UPDATE, NO PROFILE COMPLETE)
# -----------------------------------------------------------
@router.post("/resume/parse")
def parse_resume_only(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

    filename = f"{cand.id}_{uuid.uuid4()}_{file.filename}"
    filepath = os.path.join(UPLOAD_DIR, filename)

    file_bytes = file.file.read()
    with open(filepath, "wb") as f:
        f.write(file_bytes)

    # ---- TEXT EXTRACTION ----
    text = ""
    try:
        if file.filename.lower().endswith(".pdf"):
            with pdfplumber.open(filepath) as pdf:
                for p in pdf.pages:
                    text += p.extract_text() or ""
        elif file.filename.lower().endswith(".docx"):
            doc = Document(filepath)
            text = "\n".join([p.text for p in doc.paragraphs])
        else:
            text = file_bytes.decode("utf-8", "ignore")
    except:
        text = file_bytes.decode("latin-1", "ignore")

    parsed = parse_resume(text) or {}

    return {
        "message": "Resume parsed successfully",
        "resume_url": filepath,
        "parsed": {
            "full_name": parsed.get("full_name"),
            "email": parsed.get("email"),
            "phone": parsed.get("phone"),
            "skills": parsed.get("skills", []),
            "education": parsed.get("education"),
            "experience_years": parsed.get("experience_years"),
            "current_location": parsed.get("current_location"),
            "linkedin_url": parsed.get("linkedin_url"),
            "github_url": parsed.get("github_url"),
            "portfolio_url": parsed.get("portfolio_url"),
        }
    }


# -----------------------------------------------------------
# GET CURRENT CANDIDATE PROFILE (RETURN public_id)
# -----------------------------------------------------------
@router.get("/me")
def get_my_profile(
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

    # 🔥 AUTO-FIX FOR OLD CANDIDATES
    if not cand.profile_completion or cand.profile_completion == 0:
        completion = calculate_profile_completion(cand)
        cand.profile_completion = completion
        cand.profile_completed = completion >= 70
        db.commit()
        db.refresh(cand)

    return {
    "message": "success",
    "data": schemas.CandidateResponse.model_validate(cand),
    "candidate_public_id": cand.public_id
}


  

# -----------------------------------------------------------
# UPDATE PROFILE (returns candidate_public_id)
# -----------------------------------------------------------
@router.put("/me")
def update_my_profile(
    payload: schemas.CandidateSelfProfileUpdate,
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

    # ----------------------------
    # UPDATE FIELDS
    # ----------------------------
    data = payload.model_dump(exclude_unset=True)


    # ✅ LOCATION VALIDATION
    if "currentLocation" in data and data["currentLocation"]:
        is_valid, error = validate_location(data["currentLocation"], "Current Location")
        if not is_valid:
            raise HTTPException(status_code=400, detail=error)

    # ✅ CITY VALIDATION
    if "city" in data and data["city"]:
        is_valid, error = validate_location(data["city"], "City")
        if not is_valid:
            raise HTTPException(status_code=400, detail=error)

    # ✅ PINCODE VALIDATION
    if "pincode" in data and data["pincode"]:
        is_valid, error = validate_pincode(data["pincode"])
        if not is_valid:
            raise HTTPException(status_code=400, detail=error)

    # ✅ SKILLS VALIDATION
    # ✅ SKILLS VALIDATION (STRICT)
    if "skills" in data:
        if not isinstance(data["skills"], list):
            raise HTTPException(
                status_code=400,
                detail="Skills must be a list of strings"
            )
        is_valid, error = validate_skills(data["skills"])
        if not is_valid:
            raise HTTPException(status_code=400, detail=error)


    field_map = {
        "fullName": "full_name",
        "email": "email",
        "phone": "phone",
        "dateOfBirth": "date_of_birth",
        "currentLocation": "current_location",
        "city": "city",
        "pincode": "pincode",
        "resumeUrl": "resume_url",

        "skills": "skills",
        "education": "education",
        "experience": "experience",
        "currentEmployer": "current_employer",
        "previousEmployers": "previous_employers",
        "noticePeriod": "notice_period",

        "expectedCtc": "expected_ctc",
        "preferredLocation": "preferred_location",
        "languagesKnown": "languages_known",

        "linkedinUrl": "linkedin_url",
        "githubUrl": "github_url",
        "portfolioUrl": "portfolio_url",
    }

    for key, value in data.items():
        mapped_key = field_map.get(key, key)
        if hasattr(cand, mapped_key):
            setattr(cand, mapped_key, value)

    # ----------------------------
    # ✅ CALCULATE PROFILE COMPLETION (CORRECT PLACE)
    # ----------------------------
    completion = calculate_profile_completion(cand)
    cand.profile_completion = completion
    cand.profile_completed = completion >= 70
    
    db.commit()
    db.refresh(cand)

    return {
    "message": "Profile updated",
    "profile_completion": completion,
    "profile_completed": cand.profile_completed,
    "data": schemas.CandidateResponse.model_validate(cand),
}



# -----------------------------------------------------------
# UPLOAD RESUME + PARSE + VERSIONING
# -----------------------------------------------------------
# -----------------------------------------------------------
# UPLOAD RESUME (REPLACE / VERSION ONLY – NO PROFILE COMPLETE)
# -----------------------------------------------------------
@router.post("/resume")
def upload_resume(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

    version_id = str(uuid.uuid4())
    filename = f"{cand.id}_{version_id}_{file.filename}"
    filepath = os.path.join(UPLOAD_DIR, filename)

    file_bytes = file.file.read()
    with open(filepath, "wb") as f:
        f.write(file_bytes)

    text = ""
    try:
        if file.filename.lower().endswith(".pdf"):
            with pdfplumber.open(filepath) as pdf:
                for p in pdf.pages:
                    text += p.extract_text() or ""
        elif file.filename.lower().endswith(".docx"):
            doc = Document(filepath)
            text = "\n".join([p.text for p in doc.paragraphs])
        else:
            text = file_bytes.decode("utf-8", "ignore")
    except:
        text = file_bytes.decode("latin-1", "ignore")

    parsed = parse_resume(text) or {}

    # ---- VERSIONING ONLY ----
    history = cand.resume_versions or []
    history.append({
        "version_id": version_id,
        "url": filepath,
        "uploaded_at": datetime.utcnow().isoformat(),
    })

    cand.resume_versions = history
    cand.resume_url = filepath
    cand.parsed_resume = parsed
    cand.last_resume_update = datetime.utcnow()

    db.commit()
    db.refresh(cand)

    return {
        "message": "Resume uploaded",
        "resume_url": filepath,
        "candidate_public_id": cand.public_id
    }


# -----------------------------------------------------------
# APPLY TO JOB (returns candidate_public_id)
# -----------------------------------------------------------
@router.post("/me/apply")
def apply_job_frontend(
    data: schemas.CandidateApplyRequest,
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):

    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

# ✅ PHONE NUMBER VALIDATION (MANDATORY)
    if not cand.phone or not is_valid_indian_phone(cand.phone):
        raise HTTPException(
            status_code=400,
            detail="Please update a valid Indian phone number in your profile before applying"
        )

    job = db.query(models.Job).filter(models.Job.id == data.job_id).first()
    if not job:
        raise HTTPException(404, "Job not found")

    exists = db.query(models.JobApplication).filter(
        models.JobApplication.candidate_id == cand.id,
        models.JobApplication.job_id == job.id,
    ).first()

    if exists:
        raise HTTPException(409, "Already applied to this job")


    app_id = str(uuid.uuid4())

    application = models.JobApplication(
        id=app_id,
        job_id=job.id,
        candidate_id=cand.id,
        full_name=cand.full_name,
        email=cand.email,
        phone=cand.phone,
        resume_url=cand.resume_url,
        parsed_resume=cand.parsed_resume,
        status="applied",
        applied_at=datetime.utcnow(),
        cover_letter_url=data.cover_letter,
        linkedin_url=data.linkedin_url,
        portfolio_url=data.portfolio_url,

    )

    db.add(application)
    db.commit()
    create_notification(
    db,
    candidate_id=cand.id,
    title="Job Applied Successfully",
    message=f"You applied for {job.title}",
    type="application_submitted"
)



    return {
        "message": "Application submitted",
        "application_id": app_id,
        "candidate_public_id": cand.public_id
    }


# -----------------------------------------------------------
# BACKWARD COMPAT (/apply → /me/apply)
# -----------------------------------------------------------
@router.post("/apply")
def apply_job_alias(
    data: schemas.CandidateApplyRequest,
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    return apply_job_frontend(data, db, current)


# -----------------------------------------------------------
# LIST MY APPLICATIONS
# -----------------------------------------------------------
@router.get("/me/applications")
def list_my_applications(
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

    apps = (
        db.query(models.JobApplication)
        .join(models.Job, models.Job.id == models.JobApplication.job_id)
        .filter(models.JobApplication.candidate_id == cand.id)
        .order_by(models.JobApplication.applied_at.desc())
        .all()
    )

    applications = []
    for app in apps:
        applications.append({
            "application_id": app.id,
            "job_id": app.job.job_id if app.job else None,   # ✅ FIX HERE
            "job_title": app.job.title if app.job else None,
            "company_name": app.job.company_name if app.job else None,
            "status": app.status,
            "applied_at": app.applied_at,
            "resume_url": app.resume_url,
            "linkedin_url": app.linkedin_url,
            "portfolio_url": app.portfolio_url,
            "screening_score": getattr(app, "screening_score", None),

        })

    return {
        "message": "success",
        "candidate_public_id": cand.public_id,
        "applications": applications
    }

@router.get("/me/notifications")
def get_my_notifications(
    db: Session = Depends(get_db),
    current = Depends(get_current_user)
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated")

    candidate = (
        db.query(models.Candidate)
        .filter(models.Candidate.id == current["id"])
        .first()
    )

    if not candidate:
        return []

    notifications = (
        db.query(Notification)
        .filter(Notification.candidate_id == candidate.id)
        .order_by(Notification.created_at.desc())
        .all()
    )

    return [
        {
            "id": n.id,
            "title": n.title,
            "message": n.message,
            "type": n.type,
            "read": n.read,
            "created_at": n.created_at
        }
        for n in notifications
    ]



@router.put("/me/notifications/{notification_id}/read")
def mark_notification_read(
    notification_id: str,
    db: Session = Depends(get_db),
    current=Depends(get_current_user)
):
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated")

    notification = (
        db.query(Notification)
        .filter(
            Notification.id == notification_id,
            Notification.candidate_id == current["id"]
        )
        .first()
    )

    if not notification:
        raise HTTPException(404, "Notification not found")

    notification.read = True
    db.commit()
    return {"message": "Notification marked as read"}


# ============================================================
# UPLOAD PROFILE PHOTO
# ============================================================
@router.post("/me/photo")
def upload_profile_photo(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current=Depends(get_current_user),
):
    """Upload candidate profile photo"""
    if not current or current.get("type") != "candidate":
        raise HTTPException(401, "Not authenticated as candidate")

    cand = db.query(models.Candidate).filter(
        models.Candidate.id == current["id"]
    ).first()

    if not cand:
        raise HTTPException(404, "Candidate not found")

    # Validate file type
    allowed_types = {"image/jpeg", "image/png", "image/jpg"}
    if file.content_type not in allowed_types:
        raise HTTPException(400, "Only JPEG and PNG images are allowed")

    # Validate file size (max 5MB)
    file_content = file.file.read()
    if len(file_content) > 5 * 1024 * 1024:
        raise HTTPException(400, "File size must be less than 5MB")

    try:
        # Generate unique filename
        filename = f"{cand.id}_{uuid.uuid4()}.{file.filename.split('.')[-1]}"
        filepath = os.path.join(PHOTO_UPLOAD_DIR, filename)

        # Save file
        with open(filepath, "wb") as f:
            f.write(file_content)

        # Update candidate photo URL
        cand.photo_url = filepath
        db.commit()

        return {
            "message": "Photo uploaded successfully",
            "photo_url": filepath
        }
    except Exception as e:
        raise HTTPException(500, f"Failed to upload photo: {str(e)}")