# app/routes/users.py

from fastapi import APIRouter, Depends, HTTPException, status, Body
from sqlalchemy.orm import Session
from typing import List

from app.db import get_db
from app import models, schemas
from app.auth import get_current_user, get_password_hash

# Import only what REALLY exists in permissions.py
from app.permissions import ROLE_PERMISSIONS, get_all_roles_summary, get_user_permissions, MODULE_NAMES

from datetime import datetime

router = APIRouter(prefix="/v1/users", tags=["User Management"])


# -----------------------------------------------------------
# 📌 ROLE SUMMARY
# -----------------------------------------------------------
@router.get("/roles/summary")
def get_roles_summary(current_user: dict = Depends(get_current_user)):

    if current_user["role"] != "admin":
        raise HTTPException(
            status_code=403, detail="Only administrators can view role information"
        )

    return get_all_roles_summary()


# -----------------------------------------------------------
# 📌 ROLE PERMISSIONS FOR SPECIFIC ROLE
# -----------------------------------------------------------
@router.get("/roles/{role}/permissions")
def get_role_permissions(role: str, current_user: dict = Depends(get_current_user)):

    if current_user["role"] != "admin":
        raise HTTPException(
            status_code=403, detail="Only administrators can view role permissions"
        )

    if role not in ROLE_PERMISSIONS:
        raise HTTPException(status_code=404, detail=f"Role '{role}' not found")

    return {
        "role": role,
        "permissions": get_user_permissions(role),
        "summary": get_all_roles_summary().get(role, {}),
    }


# -----------------------------------------------------------
# 📌 PERMISSIONS MATRIX
# -----------------------------------------------------------
@router.get("/permissions/matrix")
def get_permissions_matrix(current_user: dict = Depends(get_current_user)):

    if current_user["role"] != "admin":
        raise HTTPException(
            status_code=403, detail="Only administrators can view permissions matrix"
        )

    matrix = {}

    for role, modules in ROLE_PERMISSIONS.items():
        matrix[role] = {}
        for module, actions in modules.items():
            readable = MODULE_NAMES.get(module, module)
            matrix[role][readable] = actions

    return matrix


# -----------------------------------------------------------
# 📌 LIST USERS (ADMIN) — EXISTING ENDPOINT
# -----------------------------------------------------------
@router.get("", response_model=List[schemas.UserResponse])
def list_users(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if current_user["role"] != "admin":
        raise HTTPException(403, "Only administrators can view all users")

    return db.query(models.User).all()


# -----------------------------------------------------------
# 📌 MISSING API #3 — LIST RECRUITERS FOR FRONTEND
# GET /v1/users?role=recruiter

# -----------------------------------------------------------
# 📌 CREATE USER (ADMIN)
# -----------------------------------------------------------
@router.post("", response_model=schemas.UserResponse, status_code=201)
def create_user(
    user_data: schemas.UserCreate,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    if current_user["role"] != "admin":
        raise HTTPException(403, "Only administrators can create users")

    # Duplicate check
    exists = db.query(models.User).filter(
        (models.User.email == user_data.email) |
        (models.User.username == user_data.username)
    ).first()

    if exists:
        raise HTTPException(400, "Username or Email already exists")

    # Validate role
    if user_data.role not in ROLE_PERMISSIONS:
        raise HTTPException(400, "Invalid role selected")

    hashed_password = get_password_hash(user_data.password or "")

    new_user = models.User(
        username=user_data.username,
        email=user_data.email,
        password=hashed_password,
        role=user_data.role,
        full_name=user_data.full_name,
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return new_user


# -----------------------------------------------------------
# 📌 GET USER
# -----------------------------------------------------------
@router.get("/{user_id}", response_model=schemas.UserResponse)
def get_user(user_id: str, db: Session = Depends(get_db), current_user: dict = Depends(get_current_user)):

    user = db.query(models.User).filter(models.User.id == user_id).first()

    if not user:
        raise HTTPException(404, "User not found")

    if current_user["role"] != "admin" and current_user["id"] != user_id:
        raise HTTPException(403, "You can only view your own profile")

    return user


# -----------------------------------------------------------
# 📌 UPDATE USER ROLE (ADMIN)
# -----------------------------------------------------------
@router.put("/{user_id}/role")
def update_user_role(
    user_id: str,
    payload: dict = Body(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if current_user["role"] != "admin":
        raise HTTPException(403, "Only administrators can update roles")

    new_role = payload.get("role")
    if not new_role:
        raise HTTPException(400, "Role is required")

    if new_role not in ROLE_PERMISSIONS:
        raise HTTPException(400, "Invalid role")

    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")

    if user.id == current_user["id"]:
        raise HTTPException(400, "You cannot change your own role")

    old = user.role
    user.role = new_role

    db.commit()
    db.refresh(user)

    return {
        "message": f"Role changed from {old} → {new_role}",
        "user": user
    }


# -----------------------------------------------------------
# 📌 DELETE USER (ADMIN)
# -----------------------------------------------------------
@router.delete("/{user_id}")
def delete_user(
    user_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    if current_user["role"] != "admin":
        raise HTTPException(403, "Only administrators can delete users")

    user = db.query(models.User).filter(models.User.id == user_id).first()

    if not user:
        raise HTTPException(404, "User not found")

    if user.id == current_user["id"]:
        raise HTTPException(400, "You cannot delete yourself")

    db.delete(user)
    db.commit()

    return {"message": f"User '{user.username}' deleted successfully"}


@router.put("/{user_id}/status")
def update_user_status(
    user_id: str,
    payload: dict = Body(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    if current_user["role"] != "admin":
        raise HTTPException(403, "Only administrators can change user status")

    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")

    if user.id == current_user["id"]:
        raise HTTPException(400, "You cannot lock yourself")

    is_active = payload.get("is_active")
    if is_active is None:
        raise HTTPException(400, "is_active is required")

    user.is_active = is_active
    db.commit()

    return {
        "message": "User status updated",
        "status": "Active" if is_active else "Locked"
    }
