from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import os
from app.routes import documents
from app.db import init_db
from app.routes import chat
# ---------------- ROUTERS ----------------
from app.auth import router as auth_router
from app.routes.jobs import router as jobs_router
from app.routes.candidates import router as candidates_router
from app.routes.interviews import router as interviews_router
from app.routes.onboarding import router as onboarding_router
from app.routes.employees import router as employees_router
from app.routes.invoices import router as invoices_router
from app.routes.alumni import router as alumni_router
from app.routes.leaves import router as leaves_router
from app.routes.settings import router as settings_router
from app.routes.careers import router as careers_router
from app.routes.leads import router as leads_router
from app.routes.communications import router as communications_router
from app.routes.performance import router as performance_router
from app.routes.users import router as users_router
from app.routes.payroll import router as payroll_router
from app.routes.campaigns import router as campaigns_router
from app.routes import matching

# ⭐ RBAC
from app.routes.roles_router import router as roles_router
from app.routes.permissions_router import router as permissions_router
from app.routes.permissions_matrix_router import router as permissions_matrix_router

# ⭐ Candidate Portal (NEW)
from app.routes.candidate_portal import router as candidate_portal_router

# ⭐ Bulk Upload (NEW)
from app.routes.bulk_upload import router as bulk_router
# -----------------------------------------
from app.routes.dashboard import router as dashboard_router
from app.routes.consultants import router as consultant_router
from app.routes.consultant_deployments import router as consultant_deployments_router
from app.routes.consultant_dashboard import router as consultant_dashboard_router
from app.routes.timesheets import router as timesheets_router


from app.routes.ai_video_interviews import router as ai_video_interview_router
from app.routes.live_interviews import router as live_interview_router, alias_router

from app.routes.interview_summary import router as interview_summary_router
from app.routes.account_manager import router as account_manager_router
from app.routes.client import router as client_router
from app.routes.recruiter import router as recruiter_router
from app.routes.notifications import router as notifications_router
from app.routes.vendor import router as vendor_router
from app.routes.bgv import router as bgv_router
from app.routes.client_admin import router as client_admin_router
from app.routes.skills import router as skills_router

# ⭐ NEW WORKFLOW ROUTERS
from app.routes.recruiter_workflows import router as recruiter_workflows_router
from app.routes.am_workflows import router as am_workflows_router
from app.routes.client_workflows import router as client_workflows_router

from sqlalchemy.orm import Session
from app.db import SessionLocal
from app.permissions import ROLE_PERMISSIONS
from app import models


def seed_permissions_to_db():
    db: Session = SessionLocal()

    # Check if permissions already exist
    existing = db.query(models.Permission).count()
    if existing > 0:
        db.close()
        return

    print("⚡ Seeding ROLE_PERMISSIONS into DB...")

    for role, modules in ROLE_PERMISSIONS.items():
        for module_name, actions in modules.items():
            for action in actions:
                perm = models.Permission(
                    role_name=role,
                    module_name=module_name,
                    action_name=action
                )
                db.add(perm)

    db.commit()
    db.close()
    print("✅ Permissions seeded successfully")

# ---------------- FASTAPI APP ----------------
app = FastAPI(
    title="Akshu HR Platform",
    description="AI-Powered End-to-End HR Automation Platform",
    version="1.0.0"
)


# ---------------- CORS ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---------------- STATIC FILES (Resume, Documents, Images) ----------------
if not os.path.exists("uploads"):
    os.makedirs("uploads")

app.mount("/uploads", StaticFiles(directory="uploads"), name="uploads")


# ---------------- INCLUDE ROUTERS ----------------
public_routers = [
    auth_router,
    careers_router,
    candidate_portal_router,   # ⭐ Candidate Self-Service APIs
    bulk_router,               # ⭐ Resume/CSV Bulk Upload
]

protected_routers = [
    jobs_router,
    skills_router,  
    candidates_router,
    interviews_router,
    onboarding_router,
    employees_router,
    documents.router,
    invoices_router,
    alumni_router,
    leaves_router,
    settings_router,
    leads_router,
    communications_router,
    performance_router,
    users_router,
    payroll_router,
    campaigns_router,
    roles_router,
    permissions_router,
    permissions_matrix_router,
    dashboard_router,
    matching.router,
    chat.router,
    consultant_router,
    consultant_deployments_router,
    consultant_dashboard_router,
    ai_video_interview_router,
    live_interview_router,
    alias_router,
    interview_summary_router,
    account_manager_router,
    client_admin_router,
    client_router,
    recruiter_router,
    notifications_router,
    vendor_router,
    bgv_router,
    timesheets_router,
    recruiter_workflows_router,
    am_workflows_router,
    client_workflows_router,

]


# Add Public Routers First
for r in public_routers:
    app.include_router(r)

# Add Protected Routers After
for r in protected_routers:
    app.include_router(r)


# ---------------- STARTUP ----------------
@app.on_event("startup")
async def startup_event():
    init_db()
    seed_permissions_to_db()

# ---------------- BASIC ENDPOINTS ----------------
@app.get("/api")
def read_root():
    return {
        "message": "Welcome to Akshu HR Platform",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
def health_check():
    return {"status": "healthy", "app": "Akshu HR Platform"}


# ---------------- FRONTEND STATIC SERVE ----------------
frontend_dist = os.path.join(os.path.dirname(__file__), "..", "..", "frontend", "dist")

if os.path.exists(frontend_dist):
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="static")
else:
    @app.get("/")
    def frontend_placeholder():
        return {"status": "ok", "message": "Frontend not built yet"}


# ---------------- RUN APP ----------------
if __name__ == "__main__":
    uvicorn.run("app.main:app", host="0.0.0.0", port=8000, reload=True)
