import enum
from sqlalchemy import (
    Column,
    String,
    Integer,
    Float,
    JSON,
    DateTime,
    Date,
    Text,
    Boolean,
    ForeignKey,
    Table,
    Enum,
)
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid
from app.db import Base
from sqlalchemy import UniqueConstraint   # 👈 add at top if not present

def validate_candidate_job_match(candidate, job):
    candidate_skills = set(candidate.skills or [])
    job_skills = set(job.skills or [])

    if not job_skills:
        raise Exception("Job skills not defined")

    matched = candidate_skills & job_skills
    match_score = len(matched) / len(job_skills)

    if match_score < 0.6:
        raise Exception("Skill mismatch")

    if candidate.experience_years is None:
        raise Exception("Candidate experience missing")

    if not (job.min_experience <= candidate.experience_years <= job.max_experience):
        raise Exception("Experience mismatch")

    return round(match_score * 100, 2)


def normalize_skill(value: str) -> str:
    if not value:
        return ""

    words = value.strip().split()
    out = []

    for w in words:
        # acronyms: AI, ML, AWS, SQL
        if len(w) <= 3 and w.isupper():
            out.append(w)
        # special tech: C++, .NET, UI/UX
        elif any(c in w for c in "+./&-"):
            out.append(w.upper())
        else:
            out.append(w.capitalize())

    return " ".join(out)

def generate_uuid() -> str:
    return str(uuid.uuid4())


def generate_candidate_public_id_from_org(db):
    """
    Generates candidate public ID like:
    ATS-C-0001
    ATS-C-0002
    """

    # 1️⃣ Get org code from system_settings
    setting = (
        db.query(SystemSettings)
        .filter(
            SystemSettings.module_name == "organization",
            SystemSettings.setting_key == "organization_code",
        )
        .first()
    )

    org_code = "ATS"
    if setting and isinstance(setting.setting_value, dict):
        org_code = setting.setting_value.get("code", "ATS")

    # 2️⃣ Get last candidate
    last_candidate = (
        db.query(Candidate.public_id)
        .filter(Candidate.public_id.like(f"{org_code}-C-%"))
        .order_by(Candidate.created_at.desc())
        .first()
    )

    if last_candidate and last_candidate[0]:
        last_number = int(last_candidate[0].split("-")[-1])
        next_number = last_number + 1
    else:
        next_number = 1

    return f"{org_code}-C-{str(next_number).zfill(4)}"


def generate_requirement_code(db):
    org_code = "ATS"

    last_req = (
        db.query(Requirement.requirement_code)
        .filter(Requirement.requirement_code.like(f"{org_code}-R-%"))
        .order_by(Requirement.created_at.desc())
        .first()
    )

    if last_req and last_req[0]:
        num = int(last_req[0].split("-")[-1])
        next_num = num + 1
    else:
        next_num = 1

    return f"{org_code}-R-{str(next_num).zfill(4)}"


# ============================================================
# ROLES & PERMISSIONS – RBAC
# ============================================================
class Role(Base):
    __tablename__ = "roles"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


class Permission(Base):
    __tablename__ = "permissions"

    id = Column(String, primary_key=True, default=generate_uuid)
    role_name = Column(String, nullable=False)
    module_name = Column(String, nullable=False)
    action_name = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================================
# USER (HR / Admin Login)
# ============================================================
class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=generate_uuid)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False, index=True)
    password = Column(String, nullable=False)

    otp_code = Column(String, nullable=True)
    otp_expiry = Column(DateTime, nullable=True)

    role = Column(String, default="employee")
    must_change_password = Column(Boolean, default=False)   # 🔥 ADD
    linked_candidate_id = Column(
        String,
        ForeignKey("candidates.id"),
        nullable=True
    )
    full_name = Column(String, nullable=True)

    # ⭐⭐ IMPORTANT — CLIENT COMPANY NAME ⭐⭐
    company_name = Column(String, nullable=True)

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    employees = relationship("Employee", back_populates="user")
    notes = relationship("CandidateNote", back_populates="author")
    login_logs = relationship("LoginLog", back_populates="user")

    assigned_jobs = relationship("Job", secondary="job_recruiters")
    # ⭐ ADD THIS FOR CLIENT → ACCOUNT MANAGER MAPPING
    account_manager_id = Column(
    String,
    ForeignKey("users.id"),
    nullable=True
)


class LoginLog(Base):
    __tablename__ = "login_logs"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"))
    username = Column(String)
    email = Column(String)
    status = Column(String)
    ip_address = Column(String)
    user_agent = Column(String)
    message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="login_logs")


# ============================================================
# JOB MODEL – used by Public Careers + ATS
# ============================================================
job_recruiters = Table(
    "job_recruiters",
    Base.metadata,
    Column("job_id", String, ForeignKey("jobs.id"), primary_key=True),
    Column("recruiter_id", String, ForeignKey("users.id"), primary_key=True),
    Column("assigned_at", DateTime, default=datetime.utcnow)
)


class Job(Base):
    __tablename__ = "jobs"

    id = Column(String, primary_key=True, default=generate_uuid)

    # 🔥 Unique Job Code like ORG-J-0001
    job_id = Column(String, unique=True, index=True)

    title = Column(String, nullable=False)
    company_name = Column(String, nullable=True)

    description = Column(Text)
    skills = Column(JSON, default=list)
    min_experience = Column(Integer, default=0)
    max_experience = Column(Integer)
    location = Column(String)
    department = Column(String)
    # ⭐ Job meta (used by frontend)
    job_type = Column(String, nullable=True)          # Full-time / Contract
    salary_range = Column(String, nullable=True)      # 10–15 LPA
    apply_by = Column(Date, nullable=True)             # last date to apply
    sla_days = Column(Integer, nullable=True)          # SLA tracking


    created_by = Column(String, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)
    status = Column(String, default="active", nullable=False)

    is_active = Column(Boolean, default=True)

    embedding_vector = Column(JSON, nullable=True)

    # ⭐ REQUIRED for JD Upload feature
    jd_url = Column(String)

    # ⭐ REQUIRED for Assign Recruiters feature
    recruiters = relationship("User", secondary="job_recruiters")

    # Existing relationships
    applications = relationship("JobApplication", back_populates="job")
    campaigns = relationship("Campaign", back_populates="job")
    client_id = Column(String, nullable=True)
    # ⭐ ADD THIS — Account Manager mapping
    account_manager_id = Column(
        String,
        ForeignKey("users.id"),
        nullable=True
    )

    account_manager = relationship(
        "User",
        foreign_keys=[account_manager_id]
    )

class CandidateClassification(str, enum.Enum):
    unclassified = "unclassified"
    payroll = "payroll"
    sourcing = "sourcing"


class Candidate(Base):
    __tablename__ = "candidates"

    id = Column(String, primary_key=True, default=generate_uuid)
    public_id = Column(String, unique=True, index=True)

    # =========================
    # Basic Info
    # =========================
    full_name = Column(String, nullable=True)
    email = Column(String, unique=True, nullable=True, index=True)
    password = Column(String, nullable=True)
    phone = Column(String)
    dob = Column(Date)

    # =========================
    # Address
    # =========================
    current_location = Column(String)
    city = Column(String)
    pincode = Column(String)
    current_address = Column(Text)
    permanent_address = Column(Text)

    # =========================
    # Application Info
    # =========================
    source = Column(String)                      # portal / recruiter / vendor / referral
    applied_job_id = Column(String)
    application_date = Column(DateTime)
    status = Column(String, default="active")
    referral = Column(String)

    # =========================
    # Vendor Support
    # =========================
    vendor_id = Column(String, nullable=True)
    is_vendor_candidate = Column(Boolean, default=False)

    billing_rate = Column(Float, nullable=True)
    payout_rate = Column(Float, nullable=True)

    # =========================
    # =========================
# Background Verification ⭐⭐
# =========================
    bgv_status = Column(String, default="new")          # new | in_progress | completed | failed
    bgv_vendor_id = Column(String, ForeignKey("vendors.id"), nullable=True)

# ⭐ Add these new important fields
    bgv_initiated = Column(Boolean, default=False)
    bgv_assigned_at = Column(DateTime, nullable=True)
    bgv_report_url = Column(Text, nullable=True)
    bgv_completed_at = Column(DateTime, nullable=True)

        # -------------------------
    # Final HR Verification
    # -------------------------
    bgv_final_status = Column(String, nullable=True)  # verified | failed
    bgv_final_remarks = Column(Text, nullable=True)
    bgv_final_verified_at = Column(DateTime, nullable=True)


    # =========================
    # Resume + Files
    # =========================
    resume_url = Column(Text)
    resume_version = Column(String)
    cover_letter_url = Column(Text)
    certificates_url = Column(Text)
    photo_url = Column(Text)
    sign_url = Column(Text)

    # =========================
    # Professional
    # =========================
    skills = Column(JSON, default=list)
    experience_years = Column(Float)
    education = Column(JSON)
    current_employer = Column(String)
    previous_employers = Column(JSON)
    notice_period = Column(String)

    linkedin_url = Column(String)
    github_url = Column(String)
    portfolio_url = Column(String)

    expected_ctc = Column(String)
    experience = Column(String)
    date_of_birth = Column(String)

    # =========================
    # AI / Parsing / Analytics
    # =========================
    parsed_resume = Column(JSON)
    embedding_vector = Column(JSON)
    resume_versions = Column(JSON)

    fit_score = Column(Float)
    fit_explanation = Column(JSON)

    # =========================
    # Tags / Logs / Profile
    # =========================
    profile_completed = Column(Boolean, default=False)
    profile_completion = Column(Integer, default=0)

    created_at = Column(DateTime, default=datetime.utcnow)

    last_login = Column(DateTime)
    internal_notes = Column(Text)
    tags = Column(JSON)
    email_logs = Column(JSON)

    # =========================
    # Preferences
    # =========================
    expected_salary = Column(Float)
    preferred_location = Column(String)
    languages_known = Column(JSON)
    social_profiles = Column(JSON)

    # =========================
    # Interview Stage
    # =========================
    interview_stage = Column(String)
    interview_feedback = Column(Text)

    # =========================
    # Forwarding / Client Submission
    # =========================
    forwarded_to = Column(String)
    forward_note = Column(Text)
    forwarded_at = Column(DateTime)

    # =========================
    # Classification
    # =========================
    classification = Column(
        Enum(CandidateClassification, name="candidateclassification"),
        nullable=False,
        default=CandidateClassification.unclassified
    )

    # =========================
    # Relationships
    # =========================
    applications = relationship("JobApplication", back_populates="candidate")
    notes = relationship("CandidateNote", back_populates="candidate")
    timeline_events = relationship("CandidateTimeline", back_populates="candidate")
    employee_record = relationship("Employee", back_populates="candidate", uselist=False)
    call_feedbacks = relationship("CallFeedback", back_populates="candidate")
        # =========================
    # Merge / Soft Delete Control
    # =========================

    # Is this candidate active & visible in ATS lists
    is_active = Column(Boolean, default=True, nullable=False)

    # If merged, points to primary candidate.id
    merged_into_id = Column(
        String,
        ForeignKey("candidates.id"),
        nullable=True
    )

    # Optional relationship (not mandatory but good)
    merged_into = relationship(
        "Candidate",
        remote_side="Candidate.id",
        lazy="joined"
    )


# ============================================================
# CONSULTANT DEPLOYMENT (Client Assignment)
# ============================================================

class ConsultantDeployment(Base):
    __tablename__ = "consultant_deployments"

    id = Column(String, primary_key=True, default=generate_uuid)
    consultant_id = Column(String, ForeignKey("consultants.id"), nullable=False)
    client_id = Column(String)

    client_name = Column(String, nullable=False)
    role = Column(String, nullable=True)

    start_date = Column(DateTime, nullable=False)
    end_date = Column(DateTime, nullable=True)

    billing_type = Column(String, nullable=False)  # monthly | hourly
    billing_rate = Column(Float, nullable=False)
    payout_rate = Column(Float, nullable=True)

    status = Column(String, default="active")
    created_at = Column(DateTime, default=datetime.utcnow)

    # ✅ ADD THIS
    consultant = relationship(
        "Consultant",
        back_populates="deployments"
    )
class TimesheetStatus(enum.Enum):
    draft = "draft"
    submitted = "submitted"
    am_approved = "am_approved"
    client_approved = "client_approved"
    rejected = "rejected"
    locked = "locked"

class Timesheet(Base):
    __tablename__ = "timesheets"

    id = Column(String, primary_key=True, default=generate_uuid)

    # 🔗 CORE LINKS
    deployment_id = Column(
        String,
        ForeignKey("consultant_deployments.id"),
        nullable=False
    )

    consultant_id = Column(
        String,
        ForeignKey("consultants.id"),
        nullable=False
    )

    client_id = Column(
        String,
        ForeignKey("users.id"),
        nullable=False
    )

    # 📅 PERIOD
    period_type = Column(String, nullable=False)   # weekly | monthly
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)

    total_hours = Column(Float, default=0)

    status = Column(
        Enum(TimesheetStatus, name="timesheet_status"),
        default=TimesheetStatus.draft,
        nullable=False
    )

    # ⏱ WORKFLOW TIMESTAMPS
    submitted_at = Column(DateTime, nullable=True)
    am_approved_at = Column(DateTime, nullable=True)
    client_approved_at = Column(DateTime, nullable=True)
    locked_at = Column(DateTime, nullable=True)

    rejection_reason = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # 🔁 RELATIONSHIPS
    deployment = relationship("ConsultantDeployment")
    consultant = relationship("Consultant")
    client = relationship("User")

    entries = relationship(
        "TimesheetEntry",
        back_populates="timesheet",
        cascade="all, delete"
    )

class TimesheetEntry(Base):
    __tablename__ = "timesheet_entries"

    id = Column(String, primary_key=True, default=generate_uuid)

    timesheet_id = Column(
        String,
        ForeignKey("timesheets.id"),
        nullable=False
    )

    work_date = Column(Date, nullable=False)
    hours = Column(Float, nullable=False)
    description = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    # 🔁 RELATIONSHIP
    timesheet = relationship(
        "Timesheet",
        back_populates="entries"
    )


# ============================================================
# JOB APPLICATIONS (Candidate Portal & ATS)
# ============================================================
class JobApplication(Base):
    __tablename__ = "job_applications"
    __table_args__ = (
        UniqueConstraint(
            "job_id",
            "candidate_id",
            name="uq_job_application_job_candidate"
        ),
    )
    id = Column(String, primary_key=True, default=generate_uuid)
    job_id = Column(String, ForeignKey("jobs.id"), nullable=False)
    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)

    full_name = Column(String)
    email = Column(String)
    phone = Column(String)

    resume_url = Column(Text)
    resume_version = Column(String)
    linkedin_url = Column(String)
    portfolio_url = Column(String)
    cover_letter_url = Column(Text)
    certificates_url = Column(Text)
    photo_url = Column(Text)
    sign_url = Column(Text)

    skills = Column(JSON, default=list)
    experience_years = Column(Float)

    parsed_resume = Column(JSON)
    screening_score = Column(Float, nullable=True)

    profile_completed = Column(Boolean, default=False)

    status = Column(String, default="applied")
    applied_at = Column(DateTime, default=datetime.utcnow)
    recruiter_id = Column(String, ForeignKey("users.id"), nullable=True)  # ⭐⭐ ADD THIS
    shortlisted_at = Column(DateTime, nullable=True)

    candidate = relationship("Candidate", back_populates="applications")
    job = relationship("Job", back_populates="applications")
    client_feedback = Column(Text, nullable=True)
    client_decision = Column(String(50), nullable=True)   # shortlisted | rejected | hired
    sent_to_am_at = Column(DateTime, nullable=True)   # ⭐ ADD THIS
    sent_to_client_at = Column(DateTime, nullable=True)
    decision_at = Column(DateTime, nullable=True)
    ready_for_assignment = Column(Boolean, default=False)


# ============================================================
# CANDIDATE SUBMISSION (RECRUITER → JOB)
# ============================================================
class CandidateSubmission(Base):
    __tablename__ = "candidate_submissions"

    __table_args__ = (
        UniqueConstraint(
            "candidate_id",
            "job_id",
            name="uq_candidate_submission"
        ),
    )

    id = Column(String, primary_key=True, default=generate_uuid)

    candidate_id = Column(
        String,
        ForeignKey("candidates.id"),
        nullable=False
    )

    job_id = Column(
        String,
        ForeignKey("jobs.id"),
        nullable=False
    )
    
    # ⭐ ADD THIS FOR REQUIREMENT TRACKING
    requirement_id = Column(
        String,
        ForeignKey("requirements.id"),
        nullable=True
    )

    recruiter_id = Column(
        String,
        ForeignKey("users.id"),
        nullable=False
    )

    match_score = Column(Float, nullable=False)
    match_details = Column(JSON, nullable=True)

    status = Column(
        String,
        default="submitted"
    )
    # submitted | shortlisted | rejected | interview | hired

    submitted_at = Column(DateTime, default=datetime.utcnow)
    shortlisted_at = Column(DateTime, nullable=True)
    decision_at = Column(DateTime, nullable=True)

    candidate = relationship("Candidate")
    job = relationship("Job")
    recruiter = relationship("User")


# ============================================================
# CANDIDATE NOTES (Admin → Add notes)
# ============================================================
class CandidateNote(Base):
    __tablename__ = "candidate_notes"

    id = Column(String, primary_key=True, default=generate_uuid)
    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)
    note = Column(Text, nullable=False)
    author_id = Column(String, ForeignKey("users.id"), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    candidate = relationship("Candidate", back_populates="notes")
    author = relationship("User", back_populates="notes")


# ============================================================
# CANDIDATE TIMELINE (Status tracking)
# ============================================================
class CandidateTimeline(Base):
    __tablename__ = "candidate_timelines"

    id = Column(String, primary_key=True, default=generate_uuid)
    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)

    status = Column(String, nullable=False)
    note = Column(Text)
    user_id = Column(String, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)

    candidate = relationship("Candidate", back_populates="timeline_events")
    user = relationship("User")


# ============================================================
# MARKETING SOURCE MANAGEMENT (Bulk sourcing system)
# ============================================================
class Campaign(Base):
    __tablename__ = "campaigns"

    id = Column(String, primary_key=True, default=generate_uuid)
    job_id = Column(String, ForeignKey("jobs.id"))

    platform = Column(String)
    campaign_name = Column(String)
    utm_source = Column(String)
    utm_medium = Column(String)
    utm_campaign = Column(String)

    budget = Column(Float)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    status = Column(String, default="active")

    impressions = Column(Integer, default=0)
    clicks = Column(Integer, default=0)
    applications = Column(Integer, default=0)
    click_through_rate = Column(Float, default=0.0)
    cost_per_application = Column(Float, default=0.0)

    created_at = Column(DateTime, default=datetime.utcnow)

    job = relationship("Job", back_populates="campaigns")
        



class Lead(Base):
    __tablename__ = "leads"

    id = Column(String, primary_key=True, default=generate_uuid)
    campaign_id = Column(String, ForeignKey("campaigns.id"))

    full_name = Column(String)
    email = Column(String)
    phone = Column(String)
    location = Column(String)
    linkedin_url = Column(String)
    source = Column(String)
    utm_params = Column(JSON)

    status = Column(String, default="new")
    score = Column(Integer, default=0)
    notes = Column(Text)

    converted_to_application_id = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_contacted_at = Column(DateTime)


# ============================================================
# INTERVIEW SYSTEM (Video / AI support)
# ============================================================
class Interview(Base):
    __tablename__ = "interviews"

    id = Column(String, primary_key=True, default=generate_uuid)
    submission_id = Column(
        String,
        ForeignKey("candidate_submissions.id"),
        nullable=False
    )

    mode = Column(String)  
    scheduled_at = Column(DateTime)
    started_at = Column(DateTime)
    completed_at = Column(DateTime)

    status = Column(String, default="scheduled")
    transcript = Column(JSON, default=list)

    total_questions = Column(Integer)
    duration_seconds = Column(Integer)
    overall_ai_score = Column(Float)

    video_path = Column(String)
    audio_path = Column(String)

    # ⭐ ADD THESE
    meeting_link = Column(String, nullable=True)
    notes = Column(Text, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    submission = relationship("CandidateSubmission")
    
    # ⭐ ADD THESE RELATIONSHIPS FOR CANDIDATE & JOB ACCESS
    @property
    def candidate(self):
        return self.submission.candidate if self.submission else None
    
    @property
    def job(self):
        return self.submission.job if self.submission else None

    scores = relationship("InterviewScore", back_populates="interview", cascade="all, delete")
    review = relationship("HumanReview", back_populates="interview", uselist=False)


class InterviewScore(Base):
    __tablename__ = "interview_scores"

    id = Column(String, primary_key=True, default=generate_uuid)
    interview_id = Column(String, ForeignKey("interviews.id"))

    dimension = Column(String)
    score = Column(Float)
    explanation = Column(Text)
    top_factors = Column(JSON)
    ai_model_version = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)

    interview = relationship("Interview", back_populates="scores")


class AIVideoInterview(Base):
    __tablename__ = "ai_video_interviews"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)
    job_id = Column(String, ForeignKey("jobs.id"), nullable=False)

    status = Column(String, default="scheduled")
    # scheduled | in_progress | completed

    questions = Column(JSON)        # list[str] – questions asked
    answers = Column(JSON)          # [{question, video_url, duration}]

    transcript = Column(JSON)       # optional (future speech-to-text)

    overall_ai_score = Column(Float)
    ai_feedback = Column(JSON)

    recording_enabled = Column(Boolean, default=True)

    started_at = Column(DateTime)
    completed_at = Column(DateTime)

    created_at = Column(DateTime, default=datetime.utcnow)

    # Optional relationships (safe to keep)
    candidate = relationship("Candidate", lazy="joined")
    job = relationship("Job", lazy="joined")


class LiveInterview(Base):
    __tablename__ = "live_interviews"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))

    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)
    job_id = Column(String, ForeignKey("jobs.id"), nullable=False)

    interviewer_id = Column(String, nullable=True)  
    # interviewer user id (HR / Admin / Panel member)

    status = Column(String, default="scheduled")
    # scheduled | in_progress | completed
     # ✅ ADD THIS LINE (VERY IMPORTANT)
    scheduled_at = Column(DateTime, nullable=True)
    meeting_url = Column(String, nullable=True)

    recording_enabled = Column(Boolean, default=True)
    recording_url = Column(String, nullable=True)

    started_at = Column(DateTime, nullable=True)
    ended_at = Column(DateTime, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    # Optional relationships (safe)
    candidate = relationship("Candidate", lazy="joined")
    job = relationship("Job", lazy="joined")


class HumanReview(Base):
    __tablename__ = "human_reviews"

    id = Column(String, primary_key=True, default=generate_uuid)
    interview_id = Column(String, ForeignKey("interviews.id"))
    reviewer_id = Column(String, ForeignKey("users.id"))

    overall_score_override = Column(Float)
    notes = Column(Text)
    decision = Column(String)  # hire / reject / hold
    reviewed_at = Column(DateTime, default=datetime.utcnow)

    interview = relationship("Interview", back_populates="review")



class AIInterviewResult(Base):
    __tablename__ = "ai_interview_results"

    id = Column(String, primary_key=True, default=generate_uuid)
    interview_id = Column(String, ForeignKey("interviews.id"))
    mode = Column(String)  # chat | video
    score = Column(Float)
    transcript = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)


class LiveInterviewResult(Base):
    __tablename__ = "live_interview_results"

    id = Column(String, primary_key=True, default=generate_uuid)
    interview_id = Column(String, ForeignKey("interviews.id"))
    interviewer_id = Column(String, nullable=True)
    rating = Column(Integer)
    comments = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class InterviewRecording(Base):
    __tablename__ = "interview_recordings"

    id = Column(String, primary_key=True, default=generate_uuid)
    interview_id = Column(String, ForeignKey("interviews.id"))
    file_url = Column(String)
    recorded_by = Column(String)  # ai | human
    created_at = Column(DateTime, default=datetime.utcnow)


class InterviewFeedback(Base):
    __tablename__ = "interview_feedbacks"

    id = Column(String, primary_key=True, default=generate_uuid)
    interview_id = Column(String, ForeignKey("interviews.id"), nullable=False)
    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)

    # Feedback content
    rating = Column(Integer, nullable=False)  # 1-5 scale
    experience_feedback = Column(Text, nullable=True)  # Qualitative feedback
    ease_of_use = Column(Integer, nullable=True)  # 1-5 scale
    comments = Column(Text, nullable=True)

    submitted_at = Column(DateTime, default=datetime.utcnow)
    created_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    interview = relationship("Interview", backref="feedback")
    candidate = relationship("Candidate")


# ============================================================
# EMPLOYEE RECORD (converted candidate to employee)
class Employee(Base):
    __tablename__ = "employees"

    id = Column(String, primary_key=True, default=generate_uuid)

    candidate_id = Column(
        String,
        ForeignKey("candidates.id"),
        nullable=False,
        unique=True
    )

    user_id = Column(
        String,
        ForeignKey("users.id"),
        nullable=False
    )
    full_name = Column(String, nullable=True)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)

    employee_code = Column(String, unique=True)

    designation = Column(String)
    department = Column(String)
    manager_id = Column(String, ForeignKey("employees.id"))
    status = Column(String, default="onboarding")

    join_date = Column(DateTime)
    exit_date = Column(DateTime)
    location = Column(String)
    ctc = Column(Float)

    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # ================= RELATIONSHIPS =================

    candidate = relationship(
        "Candidate",
        back_populates="employee_record",
        lazy="joined"
    )

    user = relationship(
        "User",
        back_populates="employees"
    )

    manager = relationship(
        "Employee",
        remote_side="Employee.id",
        backref="team_members"
    )

    onboarding_tasks = relationship(
        "OnboardingTask",
        back_populates="employee",
        cascade="all, delete"
    )

    performance_reviews = relationship(
        "PerformanceReview",
        back_populates="employee",
        cascade="all, delete"
    )

    exit_interview = relationship(
        "ExitInterview",
        back_populates="employee",
        uselist=False
    )

    alumni_record = relationship(
        "Alumni",
        back_populates="employee",
        uselist=False
    )

# app/models/consultant.py (or models.py me add)

class ConsultantType(enum.Enum):
    sourcing = "sourcing"
    payroll = "payroll"




class Consultant(Base):
    __tablename__ = "consultants"

    id = Column(String, primary_key=True, default=generate_uuid)

    candidate_id = Column(
        String,
        ForeignKey("candidates.id"),
        nullable=False,
        unique=True
    )

    user_id = Column(
        String,
        ForeignKey("users.id"),
        nullable=False
    )

    client_id = Column(
        String,
        ForeignKey("users.id"),
        nullable=True
    )

    consultant_code = Column(String, unique=True)

    type = Column(
        Enum(ConsultantType, name="consultant_type"),
        nullable=False
    )

    status = Column(String, default="available")

    billing_rate = Column(Float)
    payout_rate = Column(Float)
    payroll_ready = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    # ✅ RELATIONSHIPS (VERY IMPORTANT)
    user = relationship(
        "User",
        foreign_keys=[user_id]
    )

    client = relationship(
        "User",
        foreign_keys=[client_id]
    )

    candidate = relationship("Candidate", lazy="joined")

    deployments = relationship(
        "ConsultantDeployment",
        back_populates="consultant",
        cascade="all, delete"
    )


class Document(Base):
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))
    category = Column(String)                     # aadhar, pan, resume, offer_letter, etc.
    filename = Column(String)
    storage_path = Column(String)
    file_size = Column(Integer)
    mime_type = Column(String)
    uploaded_by = Column(String, ForeignKey("users.id"))
    uploaded_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", backref="documents")




class DocumentAudit(Base):
    __tablename__ = "document_audits"

    id = Column(String, primary_key=True, default=generate_uuid)
    # document_id = Column(String, ForeignKey("documents.id")) # comment/remove
    document_id = Column(String)   # without FK for now

    user_id = Column(String, ForeignKey("users.id"))
    action = Column(String)  # upload, download, delete
    created_at = Column(DateTime, default=datetime.utcnow)

# ============================================================
# ONBOARDING TASKS
# ============================================================
class OnboardingTask(Base):
    __tablename__ = "onboarding_tasks"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))

    title = Column(String)
    description = Column(Text)
    task_type = Column(String)
    status = Column(String, default="pending")
    assigned_to = Column(String, ForeignKey("users.id"), nullable=True)

    due_date = Column(DateTime)
    completed_at = Column(DateTime)

    documents_required = Column(JSON)
    documents_submitted = Column(JSON)

    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", back_populates="onboarding_tasks")
    # note: relationship to User is optional and only one-sided if needed:
    # assignee = relationship("User")


# ============================================================
# PERFORMANCE REVIEW
# ============================================================
class PerformanceReview(Base):
    __tablename__ = "performance_reviews"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))
    reviewer_id = Column(String, ForeignKey("users.id"))

    review_period_start = Column(DateTime)
    review_period_end = Column(DateTime)
    overall_rating = Column(Float)

    goals_achieved = Column(JSON)
    strengths = Column(Text)
    areas_of_improvement = Column(Text)
    comments = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship("Employee", back_populates="performance_reviews")


# ============================================================
# EXIT INTERVIEW
# ============================================================
class ExitInterview(Base):
    __tablename__ = "exit_interviews"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))
    interviewer_id = Column(String, ForeignKey("users.id"))

    exit_reason = Column(String)
    feedback = Column(Text)
    would_rehire = Column(Boolean)
    would_recommend = Column(Boolean)

    conducted_at = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship(
        "Employee",
        back_populates="exit_interview"
    )


# ============================================================
# ALUMNI RECORD
# ============================================================
class Alumni(Base):
    __tablename__ = "alumni"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))

    exit_date = Column(DateTime)
    last_designation = Column(String)
    tenure_years = Column(Float)

    current_company = Column(String)
    current_designation = Column(String)
    linkedin_url = Column(String)

    is_eligible_for_rehire = Column(Boolean, default=True)
    referrals_made = Column(Integer, default=0)
    engagement_score = Column(Float)

    created_at = Column(DateTime, default=datetime.utcnow)

    employee = relationship(
        "Employee",
        back_populates="alumni_record"
    )


# ============================================================
# LEAVES SYSTEM
# ============================================================
class LeaveRequest(Base):
    __tablename__ = "leave_requests"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))

    leave_type = Column(String)
    start_date = Column(DateTime)
    end_date = Column(DateTime)
    days_count = Column(Float)

    reason = Column(Text)
    status = Column(String, default="pending")
    approved_by = Column(String, ForeignKey("users.id"))
    approved_at = Column(DateTime)

    created_at = Column(DateTime, default=datetime.utcnow)


class LeaveBalance(Base):
    __tablename__ = "leave_balances"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))

    leave_type = Column(String)
    total_allocated = Column(Float, default=0.0)
    used = Column(Float, default=0.0)
    available = Column(Float, default=0.0)
    year = Column(Integer)

    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================================
# PAYROLL MODULE
# ============================================================
class EmployeeSalary(Base):
    __tablename__ = "employee_salaries"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))

    basic_salary = Column(Float)
    hra = Column(Float, default=0.0)
    transport_allowance = Column(Float, default=0.0)
    medical_allowance = Column(Float, default=0.0)
    special_allowance = Column(Float, default=0.0)

    other_allowances = Column(JSON)
    gross_salary = Column(Float)

    bank_name = Column(String)
    account_number = Column(String)
    ifsc_code = Column(String)
    pan_number = Column(String)

    effective_from = Column(DateTime)
    effective_to = Column(DateTime)
    is_active = Column(Boolean, default=True)
    currency = Column(String, default="INR")

    created_at = Column(DateTime, default=datetime.utcnow)


class SalaryDeduction(Base):
    __tablename__ = "salary_deductions"

    id = Column(String, primary_key=True, default=generate_uuid)
    employee_id = Column(String, ForeignKey("employees.id"))

    deduction_type = Column(String)
    description = Column(String)
    amount = Column(Float)
    is_percentage = Column(Boolean, default=False)

    is_recurring = Column(Boolean, default=True)
    start_date = Column(DateTime)
    end_date = Column(DateTime)

    created_at = Column(DateTime, default=datetime.utcnow)


class PayrollRun(Base):
    __tablename__ = "payroll_runs"

    id = Column(String, primary_key=True, default=generate_uuid)

    period_month = Column(Integer)
    period_year = Column(Integer)
    period_start = Column(DateTime)
    period_end = Column(DateTime)

    total_employees = Column(Integer, default=0)
    total_gross = Column(Float, default=0.0)
    total_deductions = Column(Float, default=0.0)
    total_net = Column(Float, default=0.0)

    status = Column(String, default="draft")
    processed_by = Column(String, ForeignKey("users.id"))
    processed_at = Column(DateTime)

    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)


class PaySlip(Base):
    __tablename__ = "payslips"

    id = Column(String, primary_key=True, default=generate_uuid)
    payroll_run_id = Column(String, ForeignKey("payroll_runs.id"))
    employee_id = Column(String, ForeignKey("employees.id"))

    basic_salary = Column(Float)
    hra = Column(Float, default=0.0)
    transport_allowance = Column(Float, default=0.0)
    medical_allowance = Column(Float, default=0.0)
    special_allowance = Column(Float, default=0.0)

    other_earnings = Column(JSON)
    gross_salary = Column(Float)

    tax_deduction = Column(Float, default=0.0)
    provident_fund = Column(Float, default=0.0)
    insurance = Column(Float, default=0.0)
    loan_repayment = Column(Float, default=0.0)
    other_deductions = Column(JSON)
    total_deductions = Column(Float, default=0.0)

    net_salary = Column(Float)
    working_days = Column(Integer, default=0)
    present_days = Column(Integer, default=0)
    leave_days = Column(Integer, default=0)

    payment_status = Column(String, default="pending")
    payment_date = Column(DateTime)
    payment_method = Column(String)
    payment_reference = Column(String)

    created_at = Column(DateTime, default=datetime.utcnow)


# ============================================================
# FINANCE / AUDIT / SYSTEM SETTINGS
# ============================================================
class Invoice(Base):
    __tablename__ = "invoices"

    id = Column(String, primary_key=True, default=generate_uuid)
    client_name = Column(String)
    client_id = Column(String)
    invoice_number = Column(String, unique=True)
    amount = Column(Float)
    status = Column(String, default="draft")
    placements = Column(JSON)
    due_date = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)


class AIAudit(Base):
    __tablename__ = "ai_audit"

    id = Column(String, primary_key=True, default=generate_uuid)
    decision_type = Column(String)
    model_name = Column(String)
    model_version = Column(String)
    input_data = Column(JSON)
    output_data = Column(JSON)
    confidence_score = Column(Float)
    explanation = Column(JSON)
    related_entity_id = Column(String)
    related_entity_type = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)


class SystemSettings(Base):
    __tablename__ = "system_settings"

    id = Column(String, primary_key=True, default=generate_uuid)
    module_name = Column(String)
    setting_key = Column(String)
    setting_value = Column(JSON)
    description = Column(Text)
    updated_by = Column(String, ForeignKey("users.id"))
    updated_at = Column(DateTime, default=datetime.utcnow)

# ============================================================
# Imported Candidate for Bulk Upload storage
# ============================================================
# ============================================================
# IMPORTED CANDIDATES (Bulk Upload Storage Table)
# ============================================================
class ImportedCandidate(Base):
    __tablename__ = "imported_candidates"

    id = Column(String, primary_key=True, default=generate_uuid)

    # Basic Info
    full_name = Column(String)
    email = Column(String, unique=True, nullable=False)
    phone = Column(String)
    date_of_birth = Column(String)
    resume_url = Column(Text)

    current_location = Column(String)
    current_address = Column(Text)
    permanent_address = Column(Text)

    source = Column(String)
    job_applied = Column(String)
    application_date = Column(String)
    referral = Column(String)

    # 👇 IMPORTANT (ADD THESE)
    status = Column(String, default="new")     # new | converted | failed | skipped
    candidate_id = Column(String, nullable=True)
    public_id = Column(String, nullable=True)

    skills = Column(Text)
    experience = Column(String)
    education = Column(Text)

    current_employer = Column(String)
    previous_employers = Column(Text)
    notice_period = Column(String)

    expected_salary = Column(String)
    preferred_location = Column(String)
    languages_known = Column(Text)
    social_profiles = Column(Text)

    internal_notes = Column(Text)
    tags = Column(Text)

    created_at = Column(DateTime, default=datetime.utcnow)

# ==========================
# CHAT MODEL
# ==========================
class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(String, primary_key=True, index=True, default=generate_uuid)
    sender_id = Column(String, nullable=False)         # admin/candidate id
    receiver_id = Column(String, nullable=False)       # jisko msg bheja
    message = Column(Text, nullable=True)              # plain text
    file_url = Column(String, nullable=True)           # file/image/pdf
    file_type = Column(String, nullable=True)          # image/pdf/video
    created_at = Column(DateTime, default=datetime.utcnow)


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(String, primary_key=True, default=generate_uuid)

    candidate_id = Column(
        String,
        ForeignKey("candidates.id"),
        nullable=False
    )

    title = Column(String, nullable=False)
    message = Column(Text, nullable=True)

    type = Column(String, default="info")
    # examples:
    # application_submitted
    # interview_scheduled
    # status_changed
    # profile_completed
    # admin_note

    read = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    candidate = relationship("Candidate", backref="notifications")


class Requirement(Base):
    __tablename__ = "requirements"

    id = Column(String, primary_key=True, default=generate_uuid)

    # ⭐ ADD THIS
    requirement_code = Column(String, unique=True, index=True)

    client_id = Column(String, ForeignKey("users.id"))
    title = Column(String, nullable=False)

    skills = Column(String)
    budget = Column(Float)
    sla = Column(String)
    location = Column(String)
    duration = Column(String)
    approved_at = Column(DateTime, nullable=True)
    activated_at = Column(DateTime, nullable=True)

    job_id = Column(String, ForeignKey("jobs.id"), nullable=True)

    status = Column(String, default="new")

    created_at = Column(DateTime, default=datetime.utcnow)
    account_manager_id = Column(
    String,
    ForeignKey("users.id"),
    nullable=True
)



class Vendor(Base):
    __tablename__ = "vendors"

    id = Column(String, primary_key=True, default=generate_uuid)

    company_name = Column(String, nullable=False)
    gst_number = Column(String, nullable=True)
    payment_terms = Column(String, default="NET_30")

    primary_contact_name = Column(String, nullable=True)
    primary_contact_email = Column(String, nullable=True)
    primary_contact_phone = Column(String, nullable=True)

    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class VendorDocument(Base):
    __tablename__ = "vendor_documents"

    id = Column(String, primary_key=True, default=generate_uuid)
    vendor_id = Column(String, ForeignKey("vendors.id"))

    document_type = Column(String)   # GST, NDA, Agreement, Insurance
    file_path = Column(Text)
    status = Column(String, default="uploaded")

    uploaded_at = Column(DateTime, default=datetime.utcnow)

    vendor = relationship("Vendor")


class ClientContact(Base):
    __tablename__ = "client_contacts"

    id = Column(String, primary_key=True, default=generate_uuid)

    client_id = Column(String, ForeignKey("users.id"), nullable=False)

    name = Column(String, nullable=False)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

    client = relationship("User")


class EmployeeLog(Base):
    __tablename__ = "employee_logs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    employee_id = Column(UUID(as_uuid=True), ForeignKey("employees.id"))
    action = Column(String, nullable=False)

    old_value = Column(JSON, nullable=True)
    new_value = Column(JSON, nullable=True)

    created_at = Column(DateTime, default=datetime.utcnow)

class Skill(Base):
    __tablename__ = "skills"

    id = Column(String, primary_key=True, default=generate_uuid)
    name = Column(String, nullable=False)              # Display name
    normalized_name = Column(String, nullable=False)  # lowercase key
    created_at = Column(DateTime, default=datetime.utcnow)

    __table_args__ = (
        UniqueConstraint("normalized_name", name="uq_skill_normalized"),
    )


class AuditLog(Base):
    """
    Audit trail for all workflow actions and state transitions
    Tracks: Who, What, When, Old State, New State
    """
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)  # Who did it
    action = Column(String, nullable=False)  # e.g., "CANDIDATE_CREATED", "SUBMISSION_APPROVED"
    entity_type = Column(String, nullable=False)  # e.g., "candidate", "submission", "deployment"
    entity_id = Column(String, nullable=False)  # ID of the entity being changed
    old_state = Column(String, nullable=True)  # Previous state/value
    new_state = Column(String, nullable=False)  # New state/value
    details = Column(JSON, nullable=True)  # Additional metadata
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)

    # Relationships
    user = relationship("User")

    __table_args__ = (
        UniqueConstraint("id", name="uq_audit_id"),
    )


# ============================================================
# CALL FEEDBACK SYSTEM (Recruiter feedback after candidate calls)
# ============================================================
class CallFeedback(Base):
    __tablename__ = "call_feedbacks"

    id = Column(String, primary_key=True, default=generate_uuid)
    candidate_id = Column(String, ForeignKey("candidates.id"), nullable=False)
    recruiter_id = Column(String, ForeignKey("users.id"), nullable=False)

    # =========================
    # Call Metadata
    # =========================
    call_type = Column(String, nullable=False)  # Initial Screening, HR Round, Technical Discussion, Follow-up
    call_date = Column(DateTime, nullable=False)
    call_duration = Column(Integer, nullable=True)  # in minutes
    call_mode = Column(String, nullable=False)  # Phone, Google Meet, Zoom, WhatsApp

    # =========================
    # Structured Evaluation (Star Ratings 1-5)
    # =========================
    ratings = Column(JSON, nullable=False)  # { "communication": 4, "technical_fit": 3, "experience_relevance": 4, "culture_fit": 5 }
    salary_alignment = Column(String, nullable=False)  # Yes, No, Negotiable

    # =========================
    # Recruiter Notes
    # =========================
    strengths = Column(Text, nullable=True)
    concerns = Column(Text, nullable=True)
    additional_notes = Column(Text, nullable=True)

    # =========================
    # Candidate Intent & Decision
    # =========================
    candidate_intent = Column(String, nullable=True)  # Actively looking, Passive, Offer in hand, Just exploring
    decision = Column(String, nullable=False)  # Proceed to Next Round, Hold / Revisit Later, Reject, Needs Another Call
    rejection_reason = Column(String, nullable=True)  # Skill mismatch, Salary mismatch, Experience mismatch, Not interested, No show
    
    # =========================
    # Next Actions
    # =========================
    next_actions = Column(JSON, nullable=True)  # ["Schedule technical interview", "Set follow-up reminder", "Assign interviewer"]
    
    # =========================
    # Metadata
    # =========================
    is_draft = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    candidate = relationship("Candidate", back_populates="call_feedbacks")
    recruiter = relationship("User")


# ============================================================
# USER PROFILE & SETTINGS MODULE TABLES
# ============================================================
class UserPreferences(Base):
    __tablename__ = "user_preferences"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False, unique=True)
    email_notifications = Column(Boolean, default=True)
    sms_alerts = Column(Boolean, default=False)
    report_emails = Column(Boolean, default=True)
    interview_reminders = Column(Boolean, default=True)
    two_factor_enabled = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class PasswordResetLog(Base):
    __tablename__ = "password_reset_logs"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    reset_count = Column(Integer, default=0)
    last_reset_date = Column(DateTime)
    is_locked = Column(Boolean, default=False)
    request_reason = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class AccountActivityLog(Base):
    __tablename__ = "account_activity_logs"

    id = Column(String, primary_key=True, default=generate_uuid)
    user_id = Column(String, ForeignKey("users.id"), nullable=False)
    action_type = Column(String, nullable=False)
    ip_address = Column(String, nullable=True)
    device_info = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
