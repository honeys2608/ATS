"""
Resume Parsing Service
Extracts text and data from resumes (PDF/DOCX)
"""

import re
import json
import PyPDF2
from docx import Document
from typing import Dict, Any, List, Optional

# Skill patterns database
SKILL_PATTERNS = {
    "python": r"\bpython\b",
    "javascript": r"\b(javascript|js)\b",
    "typescript": r"\btypescript\b",
    "react": r"\breact\b",
    "vue": r"\bvue\b",
    "angular": r"\bangular\b",
    "nodejs": r"\b(node\.?js|nodejs)\b",
    "fastapi": r"\bfastapi\b",
    "django": r"\bdjango\b",
    "flask": r"\bflask\b",
    "sql": r"\b(sql|mysql|postgresql|sqlite)\b",
    "mongodb": r"\bmongodb\b",
    "redis": r"\bredis\b",
    "docker": r"\bdocker\b",
    "kubernetes": r"\b(kubernetes|k8s)\b",
    "aws": r"\b(aws|amazon web services)\b",
    "gcp": r"\b(gcp|google cloud)\b",
    "azure": r"\b(azure|microsoft azure)\b",
    "git": r"\bgit\b",
    "linux": r"\b(linux|ubuntu)\b",
    "windows": r"\bwindows\b",
    "macos": r"\b(mac|macos)\b",
    "html": r"\bhtml\b",
    "css": r"\bcss\b",
    "java": r"\bjava\b",
    "csharp": r"\b(c#|csharp)\b",
    "golang": r"\b(go|golang)\b",
    "rust": r"\brust\b",
    "php": r"\bphp\b",
    "ruby": r"\bruby\b",
    "scala": r"\bscala\b",
    "r": r"\br\b",
    "matlab": r"\bmatlab\b",
    "tensorflow": r"\btensorflow\b",
    "pytorch": r"\bpytorch\b",
    "scikit-learn": r"\b(scikit-learn|sklearn)\b",
    "pandas": r"\bpandas\b",
    "numpy": r"\bnumpy\b",
    "spark": r"\b(apache spark|spark)\b",
    "hadoop": r"\bhadoop\b",
    "kafka": r"\bkafka\b",
    "elasticsearch": r"\belasticsearch\b",
    "graphql": r"\bgraphql\b",
    "rest": r"\brest\b",
    "soap": r"\bsoap\b",
    "xml": r"\bxml\b",
    "json": r"\bjson\b",
    "yaml": r"\byaml\b",
    "jira": r"\bjira\b",
    "confluence": r"\bconfluence\b",
    "slack": r"\bslack\b",
    "figma": r"\bfigma\b",
    "xd": r"\badobe\s+xd\b",
}

# Education patterns
DEGREE_PATTERNS = {
    "bachelor": r"\b(b\.?a|b\.?s|bachelor|bs)\b",
    "master": r"\b(m\.?a|m\.?s|master|masters|ms)\b",
    "phd": r"\b(ph\.?d|phd|doctorate)\b",
    "diploma": r"\b(diploma|cert|certificate)\b",
}


def extract_text_from_pdf(file_path: str) -> str:
    """Extract text from PDF file."""
    text = ""
    try:
        with open(file_path, "rb") as file:
            pdf_reader = PyPDF2.PdfReader(file)
            for page in pdf_reader.pages:
                text += page.extract_text() + "\n"
    except Exception as e:
        print(f"Error extracting PDF: {e}")
    return text


def extract_text_from_docx(file_path: str) -> str:
    """Extract text from DOCX file."""
    text = ""
    try:
        doc = Document(file_path)
        for para in doc.paragraphs:
            text += para.text + "\n"
    except Exception as e:
        print(f"Error extracting DOCX: {e}")
    return text


def extract_text(file_path: str) -> str:
    """Extract text from resume (PDF or DOCX)."""
    if file_path.lower().endswith(".pdf"):
        return extract_text_from_pdf(file_path)
    elif file_path.lower().endswith(".docx"):
        return extract_text_from_docx(file_path)
    else:
        return ""


def normalize_skill(skill: str) -> str:
    """Normalize skill name."""
    return skill.strip().lower().title()


def extract_skills(text: str) -> List[str]:
    """Extract skills from resume text."""
    text_lower = text.lower()
    found_skills = set()

    for skill_name, pattern in SKILL_PATTERNS.items():
        if re.search(pattern, text_lower, re.IGNORECASE):
            found_skills.add(normalize_skill(skill_name.replace("-", " ")))

    return sorted(list(found_skills))


def extract_contact_info(text: str) -> Dict[str, Optional[str]]:
    """Extract contact information from resume."""
    contact = {
        "email": None,
        "phone": None,
        "linkedin": None,
        "github": None,
    }

    # Email extraction
    email_pattern = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"
    email_match = re.search(email_pattern, text)
    if email_match:
        contact["email"] = email_match.group(0)

    # Phone extraction (basic patterns for various formats)
    phone_pattern = r"(\+\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"
    phone_match = re.search(phone_pattern, text)
    if phone_match:
        contact["phone"] = phone_match.group(0).strip()

    # LinkedIn extraction
    linkedin_pattern = r"linkedin\.com/in/[\w-]+"
    linkedin_match = re.search(linkedin_pattern, text)
    if linkedin_match:
        contact["linkedin"] = linkedin_match.group(0)

    # GitHub extraction
    github_pattern = r"github\.com/[\w-]+"
    github_match = re.search(github_pattern, text)
    if github_match:
        contact["github"] = github_match.group(0)

    return contact


def extract_education(text: str) -> List[Dict[str, str]]:
    """Extract education information."""
    education = []
    lines = text.split("\n")

    for i, line in enumerate(lines):
        for degree, pattern in DEGREE_PATTERNS.items():
            if re.search(pattern, line, re.IGNORECASE):
                # Extract next 2 lines as context
                education.append({
                    "degree": degree.title(),
                    "info": line.strip(),
                })
                break

    return education[:5]  # Limit to 5 entries


def extract_experience_years(text: str) -> int:
    """Estimate years of experience from resume."""
    # Look for year mentions like "3+ years", "5 years", etc.
    experience_pattern = r"(\d+)\+?\s*(?:years?|yrs?)\s+(?:of\s+)?experience"
    matches = re.findall(experience_pattern, text, re.IGNORECASE)

    if matches:
        # Return the maximum mentioned
        return int(matches[-1])

    # Alternative: count job entries
    job_keywords = ["experience", "employment", "work history", "professional"]
    sections = 0
    for keyword in job_keywords:
        if keyword.lower() in text.lower():
            sections += 1

    return sections * 2  # Rough estimate


def extract_name(text: str) -> Optional[str]:
    """Extract candidate name (usually first line or top of document)."""
    lines = text.strip().split("\n")
    for line in lines[:5]:
        # Skip lines that are likely email, phone, or URLs
        if (
            "@" not in line
            and "(" not in line
            and len(line.strip().split()) <= 4
            and len(line.strip()) > 3
        ):
            return line.strip()
    return None


def parse_resume(file_path: str) -> Dict[str, Any]:
    """
    Main resume parsing function
    Returns structured candidate data
    """
    text = extract_text(file_path)

    if not text:
        return {
            "success": False,
            "error": "Could not extract text from file",
            "data": {},
        }

    contact = extract_contact_info(text)
    skills = extract_skills(text)
    education = extract_education(text)
    experience_years = extract_experience_years(text)
    name = extract_name(text)

    return {
        "success": True,
        "data": {
            "full_name": name or "Unknown",
            "email": contact["email"],
            "phone": contact["phone"],
            "linkedin": contact["linkedin"],
            "github": contact["github"],
            "skills": skills,
            "education": education,
            "experience_years": experience_years,
            "raw_text": text[:500],  # First 500 chars for reference
        },
    }


if __name__ == "__main__":
    # Test
    result = parse_resume("sample_resume.pdf")
    print(json.dumps(result, indent=2))
