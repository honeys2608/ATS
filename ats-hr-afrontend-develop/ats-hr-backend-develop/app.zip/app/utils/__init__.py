# Makes app.utils a package for imports like 'from app.utils.role_check import ...'
