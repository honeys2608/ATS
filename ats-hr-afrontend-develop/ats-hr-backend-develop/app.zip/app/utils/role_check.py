from fastapi import HTTPException

ADMIN_ROLES = ["admin", "hr", "recruiter", "employee", "manager"]  # add your roles here

def allow_user(current):
    if current.get("type") != "user":
        raise HTTPException(403, "Only admin type users can access this route")

def allow_candidate(current):
    if current.get("type") != "candidate":
        raise HTTPException(403, "Only candidates can access this route")
