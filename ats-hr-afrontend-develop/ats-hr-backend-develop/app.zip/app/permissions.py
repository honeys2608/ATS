"""
Role-Based Access Control (RBAC)
Fixed + Stable Version
"""

from fastapi import HTTPException
from functools import wraps
import inspect

# ---------------------------------------------------------
# MODULE NAME MAPPING
# ---------------------------------------------------------
MODULE_NAMES = {
    "jobs": "Job Management",
    "candidates": "Candidates",
    "interviews": "Interviews",
    "employees": "Employees",
    "onboarding": "Onboarding",
    "leaves": "Leave Management",
    "performance": "Performance Reviews",
    "finance": "Finance",
    "alumni": "Alumni",
    "campaigns": "Campaign Tracking",
    "leads": "Lead Management",
    "settings": "System Settings",
    "users": "User Management",
    "communications": "Communication Manager",
    "job_applications": "Job Applications",
    "dashboard": "Dashboard",

    # ⭐ NEW
    "client": "Client Management",
    "recruitment": "Recruitment",  # ⭐ AI Recruiter
}

# ---------------------------------------------------------
# ROLE PERMISSIONS
# ---------------------------------------------------------
ROLE_PERMISSIONS = {
    "admin": {
        "dashboard": ["view"],
        "jobs": ["create", "view", "update", "delete"],
        "candidates": ["create", "view", "update", "delete"],
        "interviews": ["create", "view", "update", "delete", "schedule"],
        "employees": ["create", "view", "update", "delete"],
        "onboarding": ["create", "view", "update", "delete"],
        "leaves": ["create", "view", "update", "delete", "approve"],
        "performance": ["create", "view", "update", "delete"],
        "finance": ["create", "view", "update", "delete"],
        "alumni": ["create", "view", "update", "delete"],
        "settings": ["view", "update"],
        "users": ["create", "view", "update", "delete"],
        "campaigns": ["create", "view", "update", "delete"],
        "leads": ["create", "view", "update", "delete"],
        "communications": ["send", "view"],
        "recruitment": ["use_ai", "submit_candidates", "view_reports"],  # ⭐ AI Recruiter
        "job_applications": ["create", "view", "update", "delete"],
        "documents": ["create", "view", "delete"],

        # ⭐ NEW
        "client": ["create", "view", "update", "delete"]
    },

    "recruiter": {
        "dashboard": ["view"],
        "jobs": ["create", "view", "update"],
        "candidates": ["create", "view", "update"],
        "interviews": ["create", "view", "update", "schedule"],
        "employees": ["view"],
        "onboarding": ["view", "update"],
        "leaves": ["view"],
        "performance": ["view"],
        "campaigns": ["create", "view", "update"],
        "leads": ["create", "view", "update"],
        "communications": ["send", "view"],
        "job_applications": ["view"],
        "client": ["view"],
        "recruitment": ["use_ai", "submit_candidates", "view_reports"]  # ⭐ AI Recruiter
    },

    "account_manager": {
        "jobs": ["view"],
        "candidates": ["view", "update"],
        "performance": ["view"],
        "finance": ["create", "view", "update"],
        "leads": ["create", "view", "update"],
        "job_applications": ["view"],
        "interviews": ["view", "update"],
        "client": ["create", "view", "update"],
        "recruitment": ["use_ai", "view_reports"]  # ⭐ AI Recruiter
    },

    "internal_hr": {
        "dashboard": ["view"],
        "employees": ["create", "view", "update"],
        "onboarding": ["create", "view", "update"],
        "performance": ["create", "view"],
        "leaves": ["approve", "view"],
        "alumni": ["view"],
        "interviews": ["view", "update"]
    },

    "consultant": {
        "dashboard": ["view"],
        "candidates": ["create", "view"],
        "jobs": ["view"],
        "interviews": ["view"],
        "leads": ["view"]
    },

    "employee": {
        "dashboard": ["view"],
        "employees": ["view_self"],
        "onboarding": ["view_self"],
        "leaves": ["create", "view_self"],
        "performance": ["view_self"],
        "alumni": ["view"],
        "documents": ["upload_self", "view_self"]
    },

    "accounts": {
        "dashboard": ["view"],
        "finance": ["create", "view", "update"],
        "employees": ["view"],
        "payroll": ["view", "update"]
    },

    "consultant_support": {
        "dashboard": ["view"],
        "candidates": ["view"],
        "communications": ["send", "view"],
        "jobs": ["view"]
    },

    "candidate": {
        "dashboard": ["view"],
        "jobs": ["view"],
        "candidates": ["create", "view", "upload_resume"],
        "job_applications": ["create"]
    },


    "client": {
    "client": ["create","view", "update"],
    "jobs": ["view"],
    "job_applications": ["view"]
},
    "vendor": {
    "dashboard": ["view"],
    "candidates": ["create", "view"],
    "documents": ["create", "view"]
},


}

# ---------------------------------------------------------
# HELPERS
# ---------------------------------------------------------
def has_permission(role: str, module: str, action: str) -> bool:
    if role not in ROLE_PERMISSIONS:
        return False
    return action in ROLE_PERMISSIONS.get(role, {}).get(module, [])


def get_user_permissions(role: str):
    return ROLE_PERMISSIONS.get(role, {})


def get_all_roles_summary():
    summary = {}
    for role, modules in ROLE_PERMISSIONS.items():
        summary[role] = {
            "role": role,
            "total_modules": len(modules),
            "total_permissions": sum(len(actions) for actions in modules.values()),
            "modules": modules,
        }
    return summary


# ---------------------------------------------------------
# EXACT PERMISSION DECORATOR
# ---------------------------------------------------------
def require_permission(module: str, action: str):
    def decorator(func):
        is_async = inspect.iscoroutinefunction(func)

        @wraps(func)
        async def async_wrapper(*args, current_user=None, **kwargs):
            if not current_user:
                raise HTTPException(401, "Authentication required")

            role = current_user.get("role")

            if not has_permission(role, module, action):
                raise HTTPException(
                    403,
                    f"Role '{role}' does NOT have permission '{action}' on module '{module}'."
                )

            return await func(*args, current_user=current_user, **kwargs)

        @wraps(func)
        def sync_wrapper(*args, current_user=None, **kwargs):
            if not current_user:
                raise HTTPException(401, "Authentication required")

            role = current_user.get("role")

            if not has_permission(role, module, action):
                raise HTTPException(
                    403,
                    f"Role '{role}' does NOT have permission '{action}' on module '{module}'."
                )

            return func(*args, current_user=current_user, **kwargs)

        return async_wrapper if is_async else sync_wrapper

    return decorator


# ---------------------------------------------------------
# ANY PERMISSION DECORATOR
# ---------------------------------------------------------
def require_any_permission(module: str, actions: list):
    def decorator(func):

        is_async = inspect.iscoroutinefunction(func)

        @wraps(func)
        async def async_wrapper(*args, current_user=None, **kwargs):

            if not current_user:
                raise HTTPException(401, "Authentication required")

            role = current_user.get("role")

            if not any(has_permission(role, module, a) for a in actions):
                raise HTTPException(
                    403,
                    f"Role '{role}' lacks required permissions {actions}"
                )

            return await func(*args, current_user=current_user, **kwargs)

        @wraps(func)
        def sync_wrapper(*args, current_user=None, **kwargs):

            if not current_user:
                raise HTTPException(401, "Authentication required")

            role = current_user.get("role")

            if not any(has_permission(role, module, a) for a in actions):
                raise HTTPException(
                    403,
                    f"Role '{role}' lacks required permissions {actions}"
                )

            return func(*args, current_user=current_user, **kwargs)

        return async_wrapper if is_async else sync_wrapper

    return decorator
